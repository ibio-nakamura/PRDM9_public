import json
from collections import OrderedDict
from sklearn.metrics import roc_auc_score
from sklearn import metrics


def integrate_scores_with_max_method(using_PWM_list, which_seq, chr_index):
    dict_list = []
    ret_dict = OrderedDict()
    for PWM_num in using_PWM_list: 
        current_dict = json.load(open('./loglikelihood_ratio_scores/'\
                                     +'{0}_chr_{1}_global_comp_FIMO-like_PWM_{2}.json'\
                                     .format(which_seq,chr_index,PWM_num)))
        dict_list.append(current_dict)

    representative_dict = dict_list[0]
    for i, key in enumerate(representative_dict):
        for j, dict in enumerate(dict_list):
            if i==0:
                assert len(dict)==len(representative_dict)
            current_score = dict[key]
            if j==0:
                max_score = current_score
            else:
                if max_score < current_score:
                    max_score = current_score
        ret_dict[key] = max_score
    
    assert len(ret_dict)==len(representative_dict)
    return ret_dict


def integrate_scores_with_sum_method(using_PWM_list, which_seq, chr_index):
    dict_list = []
    ret_dict = OrderedDict()
    for PWM_num in using_PWM_list: 
        current_dict = json.load(open('./loglikelihood_ratio_scores/'\
                                     +'{0}_chr_{1}_global_comp_FIMO-like_PWM_{2}.json'\
                                     .format(which_seq,chr_index,PWM_num)))
        dict_list.append(current_dict)

    representative_dict = dict_list[0]
    for i, key in enumerate(representative_dict):
        for j, dict in enumerate(dict_list):
            if i==0:
                assert len(dict)==len(representative_dict)
            current_score = dict[key]
            if j==0:
                sum_score = 2**current_score
            else:
                sum_score += 2**current_score
        ret_dict[key] = sum_score
    
    assert len(ret_dict)==len(representative_dict)
    return ret_dict


if __name__=='__main__':
    using_PWM_list = []
    for legit_PWM_num in [str(1),str(2),str(3),str(4),str(5),str(6)]:
        using_PWM_list.append(legit_PWM_num)
    for PWM_num in [str(7),str(8),str(9),str(10),str(11),str(12),str(13),str(14),str(15),str(16),str(17)]:
        using_PWM_list.append(PWM_num)
        max_hot_scores = []
        max_cold_scores = []
        sum_hot_scores = []
        sum_cold_scores = []
        y_preds = []
    
        for chr_index in [str(1),str(2),str(3),str(4),str(5),str(6),str(7),str(8),str(9),\
                          str(10),str(11),str(12),str(13),str(14),str(15),str(16),str(17),\
                          str(18),str(19),str(20),str(21),str(22),'X']:
            for which_seq in ['hot', 'cold']:
                max_dict = integrate_scores_with_max_method(using_PWM_list, which_seq, chr_index)
                max_scores = [score for score in max_dict.values()]
                sum_dict = integrate_scores_with_sum_method(using_PWM_list, which_seq, chr_index)
                sum_scores = [score for score in sum_dict.values()]

                assert len(max_scores)==len(sum_scores)
                if which_seq == 'hot':
                    max_hot_scores += max_scores
                    sum_hot_scores += sum_scores
                elif which_seq == 'cold':
                    max_cold_scores += max_scores
                    sum_cold_scores += sum_scores

        all_max_y_preds = max_hot_scores + max_cold_scores
        all_max_Y_test = [1]*len(max_hot_scores) + [0]*len(max_cold_scores)
        all_sum_y_preds = sum_hot_scores + sum_cold_scores
        all_sum_Y_test = [1]*len(sum_hot_scores) + [0]*len(sum_cold_scores)
        assert all_max_Y_test==all_sum_Y_test

        max_fpr, max_tpr, max_thresholds = metrics.roc_curve(all_max_Y_test, all_max_y_preds)
        max_auc = metrics.auc(max_fpr, max_tpr)
        sum_fpr, sum_tpr, sum_thresholds = metrics.roc_curve(all_sum_Y_test, all_sum_y_preds)
        sum_auc = metrics.auc(sum_fpr, sum_tpr)
        print('auc={0} using PWM until{1} with Max method'.format(max_auc,max([int(PWM_num) for PWM_num in using_PWM_list])))
        print('auc={0} using PWM until{1} with Sum method'.format(sum_auc,max([int(PWM_num) for PWM_num in using_PWM_list])))
        
        '''
        d = {}
        d["fpr"] = fpr.tolist()
        d["tpr"] = tpr.tolist()
        d["thresholds"] = thresholds.tolist()
        with open("AUROC_{0}bp_original.json".format(seq_len),"w") as f:
            json.dump(d,f)
        '''
        #plt.plot(fpr, tpr, label='ROC curve (area = %.4f)'%auc)
        #plt.plot(np.linspace(1, 0, len(fpr)), np.linspace(1, 0, len(fpr)), label='Random ROC curve (area = %.2f)'%0.5, linestyle='--', color='gray')