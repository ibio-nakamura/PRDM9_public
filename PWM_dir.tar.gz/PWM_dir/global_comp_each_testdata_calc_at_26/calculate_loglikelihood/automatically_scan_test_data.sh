#!/bin/bash

python PWM_main_H1.py > /dev/null &
python PWM_main_H2.py > /dev/null &
python PWM_main_H3.py > /dev/null &
python PWM_main_H4.py > /dev/null &
python PWM_main_H5.py > /dev/null &
python PWM_main_H6.py > /dev/null &
python PWM_main_H7.py > /dev/null &
python PWM_main_H8.py > /dev/null &
python PWM_main_H9.py > /dev/null &
python PWM_main_H10.py > /dev/null &
python PWM_main_H11.py > /dev/null &
python PWM_main_H12.py > /dev/null &
python PWM_main_H13.py > /dev/null &
python PWM_main_H14.py > /dev/null &
python PWM_main_H15.py > /dev/null &
python PWM_main_H16.py > /dev/null &
python PWM_main_H17.py > /dev/null &


