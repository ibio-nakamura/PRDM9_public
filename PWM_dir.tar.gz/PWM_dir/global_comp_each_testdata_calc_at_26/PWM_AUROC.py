from keras.utils import to_categorical
import numpy as np
import re
import gzip as gz
import json
from tqdm import tqdm
from sklearn import metrics
from sklearn.metrics import roc_auc_score
import matplotlib.pyplot as plt
#このプログラムではデータの分割から学習、テストデータでのAUROC描画までを一貫してやってくれる。
#参考にしたのはhttps://qiita.com/g-k/items/b47b9b0ee2015a3b0b94#%E5%88%86%E9%A1%9E%E3%82%BF%E3%82%B9%E3%82%AF
# recombination_train_and_aurocを参考に作ったPWM用のプログラム。


def AUROC4PWM(path, tag):
    hot_preds = []
    cold_preds = []

    for chr_index in [str(1),str(2),str(3),str(4),str(5),str(6),str(7),str(8),str(9),str(10),\
                    str(11),str(12),str(13),str(14),str(15),str(16),str(17),str(18),str(19),str(20),str(21),str(22),'X']:

        json_hot_open = open(path+'positive_integrated_'+tag+'_chr'+chr_index+'.json')
        json_hot_dict = json.load(json_hot_open)
        hot_preds = hot_preds+[value for value in json_hot_dict.values()]

        json_cold_open = open(path+'negative_integrated_'+tag+'_chr'+chr_index+'.json')
        json_cold_dict = json.load(json_cold_open)
        cold_preds = cold_preds+[value for value in json_cold_dict.values()]


    Y_test = [1]*len(hot_preds) + [0]*len(cold_preds)
    y_preds = hot_preds + cold_preds

    #~~~~~ここからROCを描く~~~~~~~~
    fpr, tpr, thresholds = metrics.roc_curve(Y_test, y_preds)
    auc = metrics.auc(fpr, tpr)
    print(auc)

    d = {}
    d["fpr"] = fpr.tolist()
    d["tpr"] = tpr.tolist()
    d["thresholds"] = thresholds.tolist()
    with open("ROC_PWM_"+tag+".json","w") as f:
        json.dump(d,f)
    
    plt.plot(fpr, tpr, label='ROC curve (area = %.4f)'%auc)
    plt.plot(np.linspace(1, 0, len(fpr)), np.linspace(1, 0, len(fpr)), label='Random ROC curve (area = %.2f)'%0.5, linestyle = '--', color = 'gray')
    plt.title('ROC curve')
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.grid(True)
    plt.savefig("ROC_PWM_"+tag+"_with_optimal.png")


if __name__ == "__main__":
    AUROC4PWM(path='./out_jsons/',tag='global_comp')

