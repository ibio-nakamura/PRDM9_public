from matplotlib import pyplot as plt
from collections import OrderedDict, Counter
import json
import numpy as np
import copy
import sys
import random
from tqdm import tqdm
from scipy import stats

from make_2by2_table_modules import Noverlap_hot_cold_dict_maker


def plot_histgram(CNN_positive_distance_list, CNN_negative_distance_list):
    fig = plt.figure()
    ax = fig.add_subplot(1,1,1)
    bins = np.logspace(0,10, num=50)

    # ax.set_title('Distance to the nearest ChIP-seq peak center')
    # reference: https://qiita.com/ShoheiKojima/items/fa5128c14c8365a7b89c
    neg_n, neg_bins, _ = ax.hist(x=CNN_negative_distance_list,alpha=0.3,label='PWM-negative',bins=bins)
    pos_n, pos_bins, _ = ax.hist(x=CNN_positive_distance_list,alpha=0.3,label='PWM-positive',bins=bins)
    ret_neg, ret_pos = [],[]
    plt.xlabel('Distance(bp)')
    plt.ylabel('Frequency')
    plt.xlim(10**2, 10**6.5)
    plt.xscale("log")
    plt.legend()
    plt.savefig('fast_random_sampled_100bp_PWM-positive_distance_histgram.png')


    return [pos_n, neg_n]


if __name__=='__main__':    
    hist_dict = json.load(open('PWM_distance_dict.json'))
    pos = hist_dict['PWM_pos_distance']
    neg = hist_dict['PWM_neg_distance']
    plot_histgram(pos,neg)
