from matplotlib import pyplot as plt
from collections import OrderedDict, Counter
import json
import numpy as np
import copy
import sys
import random
from tqdm import tqdm

from make_2by2_table_modules import Noverlap_PWM_hot_cold_dict_maker
from make_auged_train_data_vs_ChIP_modules import peak_seq_maker, seq_maker, make_original_hot_data
from get_optimal_threshold import main as got_main


def get_information_at_each_position(chr_index,PWM_threshold):
    ret_od = OrderedDict()
    hot_cold_judged_fname = '../../CNN_dir/peak_judgement_out/judged_chr_{0}.json'.format(chr_index)
    PWM_score_fname = './out_jsons/integrated_Noverlap_chr'+chr_index+'.json'
    current_chr_od_sorted_by_position = Noverlap_PWM_hot_cold_dict_maker(PWM_score_fname,hot_cold_judged_fname,chr_index)

    for key, value in current_chr_od_sorted_by_position.items():
        chr_info=key[0]
        pos_info=int(key[1])
        ChIP_which_info=key[2]
        prediction_score = value
        PWM_which = 0
        assert chr_info.lstrip('chr')==chr_index
        if PWM_threshold < prediction_score:
            PWM_which=1
        ret_od[(chr_info,pos_info)]=[ChIP_which_info,PWM_which]
        
    return ret_od


def devide_fragments(info_od):
    PWM_pos_ChIP_neg_center_positions = []
    PWM_neg_ChIP_neg_center_positions = []
    #ChIP_positions = []

    for key, value in info_od.items():
        chr_index = key[0].lstrip('chr')
        if chr_index == 'X':
            chr_index =23
        else:
            chr_index = int(chr_index)
        position = int(key[1])
        ChIP_which_info = value[0]
        PWM_which_info = value[1]

        if ChIP_which_info == 'hot':
            #ChIP_positions.append(position)
            continue
        else:
            if PWM_which_info==1:
                PWM_pos_ChIP_neg_center_positions.append(position)
            else:
                PWM_neg_ChIP_neg_center_positions.append(position)
    
    #return [PWM_pos_ChIP_neg_center_positions, PWM_neg_ChIP_neg_center_positions, ChIP_positions]
    return [PWM_pos_ChIP_neg_center_positions, PWM_neg_ChIP_neg_center_positions]


def getNearestValue(list, num):
    """
    概要: リストからある値に最も近い値を返却する関数
    @param list: データ配列
    @param num: 対象値
    @return 対象値に最も近い値
    """
    # リスト要素と対象値の差分を計算し最小値のインデックスを取得
    idx = np.abs(np.asarray(list) - num).argmin()
    return list[idx]


def plot_histgram(PWM_positive_distance_list, PWM_negative_distance_list):
    fig = plt.figure()
    ax = fig.add_subplot(1,1,1)
    bins = np.logspace(0,10, num=50)

    #ax.set_title('Distance to the nearest ChIP-seq peak center')
    # reference: https://qiita.com/ShoheiKojima/items/fa5128c14c8365a7b89c
    neg_n, neg_bins, _ = ax.hist(x=PWM_negative_distance_list,alpha=0.3,label='PWM-negative',bins=bins)
    pos_n, pos_bins, _ = ax.hist(x=PWM_positive_distance_list,alpha=0.3,label='PWM-positive',bins=bins)
    ret_neg, ret_pos = [],[]
    plt.xlabel('Distance (bp)')
    plt.ylabel('Frequency')
    plt.xlim(10**2, 10**6.5)
    plt.xscale("log")
    #plt.legend()
    #plt.show()
    #plt.savefig('random_sampled_100bp_PWM-positive_distance_histgram.png')
    od = OrderedDict()
    od['neg_n'] = neg_n.tolist()
    od['pos_n'] = pos_n.tolist()
    od['neg_bins'] = neg_bins.tolist()
    od['pos_bins'] = pos_bins.tolist()
    #with open('PWM_hist.json', 'w') as f:
    #    json.dump(od,f)

    return [pos_n, neg_n]


def make_start_to_the_center(start_position, region_len):
    center = start_position + int(region_len/2)
    return center


def return_start_of_ChIP_region(chr_index):
    chr_index = str(chr_index)
    peak_fragments = peak_seq_maker(file_name='../../CNN_dir/100bp_seqs/GSE99407_ChIPseq_Peaks.YFP_HumanPRDM9.antiGFP.protocolN.p10e-5.sep250.Annotated.txt.gz',\
                                    chr_index=chr_index)
    seq = seq_maker(chr_index=chr_index, PATH='../../make_Noverlap_fragments/hg19/')
    ChIP_peak_dict = make_original_hot_data(peak_fragments, seq)
    ret_list = sorted([key for key in ChIP_peak_dict.keys()])
    return ret_list


def main(chr_index, PWM_optimal_threshold, PWM_pos_distances, PWM_neg_distances, sample_size_list):
    info_od = get_information_at_each_position(chr_index=chr_index,PWM_threshold=PWM_optimal_threshold)
    PWM_pos_ChIP_neg_start_positions, PWM_neg_ChIP_neg_start_positions = devide_fragments(info_od)
    ChIP_region_start_positions = return_start_of_ChIP_region(chr_index)
    PWM_pos_ChIP_neg_center_positions, PWM_neg_ChIP_neg_center_positions, ChIP_region_center_positions = \
    [make_start_to_the_center(start,100)-1 for start in PWM_pos_ChIP_neg_start_positions], \
    [make_start_to_the_center(start,100)-1 for start in PWM_neg_ChIP_neg_start_positions], \
    [make_start_to_the_center(start,301) for start in ChIP_region_start_positions]

    sample_size = len(PWM_pos_ChIP_neg_center_positions)//10
    assert sample_size > 10
    assert sample_size<len(PWM_pos_ChIP_neg_center_positions) and sample_size<len(PWM_neg_ChIP_neg_center_positions)
    random_PWM_pos_positions = random.sample(PWM_pos_ChIP_neg_center_positions,sample_size)
    random_PWM_neg_positions = random.sample(PWM_neg_ChIP_neg_center_positions,sample_size)

    for random_PWM_pos_position, random_PWM_neg_position in zip(random_PWM_pos_positions,random_PWM_neg_positions):
        PWM_pos_nearest = getNearestValue(list=ChIP_region_center_positions,num=random_PWM_pos_position)
        PWM_pos_distances.append(abs(PWM_pos_nearest-random_PWM_pos_position))
        PWM_neg_nearest = getNearestValue(list=ChIP_region_center_positions,num=random_PWM_neg_position)
        PWM_neg_distances.append(abs(PWM_neg_nearest-random_PWM_neg_position))

    pos_n, neg_n = plot_histgram(PWM_positive_distance_list=PWM_pos_distances, PWM_negative_distance_list=PWM_neg_distances)
    print('pos_n at chr{0}: '.format(chr_index), pos_n)
    print('neg_n at chr{0}: '.format(chr_index), neg_n)
    sample_size_list.append(sample_size)
    
    return [PWM_pos_distances, PWM_neg_distances, len(PWM_pos_ChIP_neg_center_positions), len(PWM_neg_ChIP_neg_center_positions), sample_size_list]


if __name__=='__main__':
    # Use only autosome
    chr_indices = [str(i) for i in range(1,23)]
    sample_size_list = []
    PWM_pos_distances = []
    PWM_neg_distances = []
    PWM_positive_ChIP_neg_total = 0
    PWM_negative_ChIP_neg_total = 0
    PWM_optimal_threshold, fpr_at_ot, tpr_at_ot= got_main('../global_comp_each_testdata_calc_at_26/ROC_PWM_global_comp.json')
    print('fpr: ',fpr_at_ot)
    print('tpr: ',tpr_at_ot)
    
    for chr_index in tqdm(chr_indices):
        PWM_pos_distances, PWM_neg_distances, len_PWM_pos_ChIP_neg_center_positions, len_PWM_neg_ChIP_neg_center_positions, sample_size_list = \
            main(chr_index=chr_index, \
                 PWM_optimal_threshold=PWM_optimal_threshold, \
                 PWM_pos_distances=PWM_pos_distances, \
                 PWM_neg_distances=PWM_neg_distances, \
                 sample_size_list=sample_size_list)
        PWM_positive_ChIP_neg_total += len_PWM_pos_ChIP_neg_center_positions
        PWM_negative_ChIP_neg_total += len_PWM_neg_ChIP_neg_center_positions

    PWM_distance_dict = {}
    PWM_distance_dict['PWM_pos_distance'] = PWM_pos_distances
    PWM_distance_dict['PWM_neg_distance'] = PWM_neg_distances
    print('# of total PWM_positive_ChIP_neg', PWM_positive_ChIP_neg_total)
    print('# of total PWM_positive_ChIP_neg', PWM_negative_ChIP_neg_total)
    print('PWM_sample_sizes: ', sample_size_list)
    with open('PWM_distance_dict.json', 'w') as f:
        json.dump(PWM_distance_dict, f)