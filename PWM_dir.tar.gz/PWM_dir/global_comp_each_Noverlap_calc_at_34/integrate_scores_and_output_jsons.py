import json
from collections import OrderedDict


def integrate_scores_with_sum_method(using_PWM_list, chr_index):
    dict_list = []
    ret_dict = OrderedDict()
    for PWM_num in using_PWM_list: 
        current_dict = json.load(open('./loglikelihood_ratio_scores/'\
                                     +'100bp_Noverlap_chr_{0}_global_comp_FIMO-like_PWM_{1}.json'\
                                     .format(chr_index,PWM_num)))
        dict_list.append(current_dict)

    representative_dict = dict_list[0]
    for i, key in enumerate(representative_dict):
        for j, dict in enumerate(dict_list):
            if i==0:
                assert len(dict)==len(representative_dict)
            current_score = dict[key]
            if j==0:
                sum_score = 2**current_score
            else:
                sum_score += 2**current_score
        ret_dict[key] = sum_score
    
    assert len(ret_dict)==len(representative_dict)
    return ret_dict


if __name__=='__main__':
    using_PWM_list = [str(i) for i in range(1,16)]
    chr_index_list = [str(i) for i in range(1,23)]
    chr_index_list.append('X')
    for chr_index in chr_index_list:
        print('Now processing chromosome {0}...'.format(chr_index))
        ret_dict = integrate_scores_with_sum_method(using_PWM_list, chr_index)
        dir = './out_jsons/'
        with open(dir+'integrated_Noverlap_chr{0}.json'.format(chr_index),'w') as f:
            json.dump(ret_dict,f)
