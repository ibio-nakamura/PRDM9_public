import sys
import pandas as pd
import random
from Bio import SeqIO
from tqdm import tqdm
from collections import OrderedDict
import math
from sklearn.model_selection import train_test_split


def peak_seq_maker(file_name, chr_index):
    df = pd.read_csv(file_name, sep='\t')
    df_chr = df[df['chr']=='chr'+str(chr_index)]
    print(df_chr)
    df_seq = df_chr['sequence']
    print(df_seq)
    seq_list = []
    for seq in df_seq:
        seq_list.append(seq.upper())

    return seq_list


def seq_maker(chr_index, PATH):
    seq = ""
    print("Now, reconstructing chr{0} sequence from fasta file...".format(str(chr_index)))
    file_name = 'chr'+str(chr_index)+'.fa'
    with open(PATH+file_name,'r') as f:
        for seq_record in SeqIO.parse(f, "fasta"):
            seq += seq_record.seq

    return seq


def make_original_hot_data(peak_seq_list, seq):
    peak_pos_list = []
    seq = seq.upper()
    times = 0
    ret_hot_dict = OrderedDict()
    ret_pos_list = []
    ret_seq_list = []

    print("Now, collecting hotseqs...")
    for peak_hot_fragment in tqdm(peak_seq_list):
        pos = seq.find(peak_hot_fragment)
        if pos >= 1000000:
            times += 1
            seq = seq[1000000:]
            if times == 1:
                assert pos>0,'A'
                ret_hot_dict[pos] = peak_hot_fragment
            else:
                pos += (times-1)*1000000
                assert pos>0, 'B'
                ret_hot_dict[pos] = peak_hot_fragment
        else:
            pos += times*1000000
            assert pos>0, 'C'
            ret_hot_dict[pos] = peak_hot_fragment
    
    
    return ret_hot_dict


def make_training_files(hotspots, coldspots, out_hot_fname, out_cold_fname):
    with open(out_hot_fname, "w") as f:
        for i, hotseq in enumerate(hotspots):
            f.write(">hotseq"+str(i)+"\n")
            f.write((str(hotseq)).upper()+"\n")

    with open(out_cold_fname, "w") as f:
        for i, coldseq in enumerate(coldspots):
            f.write(">coldseq"+str(i)+"\n")
            f.write((str(coldseq)).upper()+"\n")

    return str(out_hot_fname)+("and")+str(out_cold_fname)+("are well done.")


def make_sample_files(hot_ordered_dict, cold_ordered_dict, out_hot_fname, out_cold_fname, chr_index):
    with open(out_hot_fname, "w") as f:
        for position, hotseq in hot_ordered_dict.items():
            f.write(">hotseq_chr"+str(chr_index)+'_'+str(position)+"\n")
            f.write((str(hotseq)).upper()+"\n")        

    with open(out_cold_fname, "w") as f:
        for position, coldseq in cold_ordered_dict.items():
            f.write(">coldseq_chr"+str(chr_index)+'_'+str(position)+"\n")
            f.write((str(coldseq)).upper()+"\n")

    return str(out_hot_fname)+("and")+str(out_cold_fname)+("are well done.")


def range_split_with_seq_len(cold_bunch_seq, range_start, seq_len):
    pos_extracted_fragments_od = OrderedDict()
    cold_fragment_len = len(cold_bunch_seq)
    NofUnit = cold_fragment_len//seq_len
    start_pos_list = []

    for i in range(NofUnit):
        relative_start_position = range_start + i*seq_len
        start_pos_list.append(relative_start_position)

    return start_pos_list


def return_random_fragment_from_start_positions(whole_seq, start_position_list, seq_len, objective_seq_number):
    ret_od = OrderedDict()
    print('objective_seq_number: ', objective_seq_number)
    sampled_start_position_list = random.sample(start_position_list, round(objective_seq_number*1.8))
    for start_position in sampled_start_position_list:
        fragment = whole_seq[start_position:start_position+seq_len]
        if 'N' not in fragment and 'n' not in fragment:
            ret_od[start_position] = fragment
        else:
            continue
    
    assert len(ret_od) > objective_seq_number, len(ret_od)
    return ret_od


def extract_cold_data_with_min_separation_distance(original_hot_od, seq, augtimes, \
                                                   MIN_SEP_DISTANCE, fragment_len):
    uncorrect_seq_list = []
    cold_fragments = []
    original_seq = seq
    ret_seq_list = []
    peak_pos_list = [key for key in original_hot_od]
    cold_od = OrderedDict()
    cold_range_start_dict = OrderedDict()
    objective_cold_data_size = math.ceil(len(peak_pos_list)*augtimes)
    cold_pool_list = []

    print("Now, collecting negative-seqs...")
    for i, peak_hot_fragment_pos in enumerate(peak_pos_list):
        #この分岐がないとpeak_pos_list[i+1]がlist index out of rangeにはまる.
        if i < len(peak_pos_list)-1:
            current_pos = peak_pos_list[i]
            current_peak = current_pos + 150
            next_pos = peak_pos_list[i+1]
            next_peak = next_pos + 150
            range_start = current_peak + MIN_SEP_DISTANCE + 1
            range_end = next_peak - MIN_SEP_DISTANCE - 1
            if range_start < range_end:
                cold_range_seq = seq[range_start:range_end+1]
            else:
                cold_range_seq = None
            
            if cold_range_seq and len(cold_range_seq) > fragment_len:
                cold_range_start_dict[range_start] = cold_range_seq

    for range_start, cold_range_seq in cold_range_start_dict.items():
        start_pos_list = range_split_with_seq_len(cold_range_seq, range_start, fragment_len)
        for start_pos in start_pos_list:
            cold_pool_list.append(start_pos)

    cold_od = return_random_fragment_from_start_positions(whole_seq=seq, start_position_list=cold_pool_list, \
                                                          seq_len=fragment_len, objective_seq_number=objective_cold_data_size)

    return cold_od


def make_original_hot_od_narrow(original_hot_od, seq_len):
    ret_od = OrderedDict()
    for start, fragment in original_hot_od.items():
        CENTER=150
        start += seq_len
        # /2 returns float type object even if it can be no residue like 4/2=2.0.
        fragment = fragment[int(CENTER-(seq_len/2))+1:int(CENTER+(seq_len/2)+1)]
        ret_od[start] = fragment

    assert len(fragment)==seq_len, len(fragment)
    return ret_od


def data_split(hot_od, cold_od):
    hot_test_size = len(hot_od)//10
    # key has position on the chromosome.
    hot_keys = [key for key in hot_od]
    cold_keys = [key for key in cold_od]
    print("negative_keys: ",len(cold_keys))
    print("positive_size*49: ", hot_test_size*49)
    X_the_rest_hot, X_test_hot = train_test_split(hot_keys, test_size=hot_test_size)
    X_the_rest_cold, X_test_cold  = train_test_split(cold_keys, test_size=hot_test_size*49)
    print("length of X_test_positive: ", len(X_test_hot))
    print("length of X_test_negative: ", len(X_test_cold))
    print("length of X_the_rest_positive: ", len(X_the_rest_hot))
    print("length of X_the_rest_negative: ", len(X_the_rest_cold))
    
    return [X_the_rest_hot, X_the_rest_cold, X_test_hot, X_test_cold]


# ピーク中心を移動させることができる.
def peak_allocation_for_narrow_seq(seq, data_pos, seq_len):
    three_strike = 0
    while three_strike<3:
        # /2 returns float type object even if it can be no residue like 4/2=2.0.
        original_center = int(((data_pos)+(data_pos+seq_len))/2)-1
        center_left = original_center - 15
        center_right = original_center + 15
        max_start = center_left
        min_start = center_right - (seq_len-1)
        new_start = random.randrange(min_start, max_start+1)
        allocated_peak_seq = seq[new_start:new_start+seq_len]
        if not("N" in allocated_peak_seq):
            break
        else:
            three_strike+=1
            print(allocated_peak_seq)
            allocated_peak_seq=None
        
    return allocated_peak_seq


#　今度は入力したピークデータに対してピークを移動して複数の配列を返す.
def peak_allocation_augmentation_for_narrow_seq(seq, data_pos_list, aug_times, seq_len):
    ret_seqs = []

    print("Now, random peak re-allocation is being conducted...")
    for data_pos in data_pos_list:
        for i in range(int(aug_times)):
            allocated_seq = peak_allocation_for_narrow_seq(seq, data_pos, seq_len)
            if allocated_seq:
                ret_seqs.append(allocated_seq)
            else:
                print(data_pos)
                
    return ret_seqs


