from matplotlib import pyplot as plt
from collections import OrderedDict, Counter
import json
import numpy as np
import copy
import sys
import random
from tqdm import tqdm
from scipy import stats
from pprint import pprint


if __name__=='__main__':
    CNN_distance_dict = json.load(open('../CNN_dir/CNN_distance_dict.json'))
    PWM_distance_dict = json.load(open('../PWM_dir/global_comp_each_Noverlap_calc_at_34/PWM_distance_dict.json'))
    
    CNN_pos_distances = CNN_distance_dict['CNN_pos_distance']
    CNN_neg_distances = CNN_distance_dict['CNN_neg_distance']
    PWM_pos_distances = PWM_distance_dict['PWM_pos_distance']
    
    print(len(CNN_pos_distances))
    print(len(CNN_neg_distances))
    print(len(PWM_pos_distances))

    # https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.mannwhitneyu.html
    print('CNN-pos and CNN-neg')
    print(stats.mannwhitneyu(CNN_pos_distances, CNN_neg_distances, alternative='less')) 

    print('CNN-pos and PWM-pos')
    print(stats.mannwhitneyu(CNN_pos_distances, PWM_pos_distances, alternative='less'))
    
