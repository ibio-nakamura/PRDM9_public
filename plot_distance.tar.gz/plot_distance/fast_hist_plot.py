from matplotlib import pyplot as plt
from collections import OrderedDict, Counter
import json
import numpy as np
import copy
import sys
import random
from tqdm import tqdm
from scipy import stats


def plot_CNN_histgram(CNN_positive_distance_list, CNN_negative_distance_list):
    fig = plt.figure()
    ax = fig.add_subplot(1,1,1)
    bins = np.logspace(0,10, num=50)

    # ax.set_title('Distance to the nearest ChIP-seq peak center')
    # reference: https://qiita.com/ShoheiKojima/items/fa5128c14c8365a7b89c
    CNN_neg_n, neg_bins, _ = ax.hist(x=CNN_negative_distance_list,label='CNN-negative',bins=bins,alpha=0.3)
    CNN_pos_n, pos_bins, _ = ax.hist(x=CNN_positive_distance_list,label='CNN-positive',bins=bins,alpha=0.3)
    #PWM_pos_n, pos_bins, _ = ax.hist(x=PWM_positive_distance_list,label='PWM-positive',bins=bins,histtype="step")
    plt.xlabel('Distance (bp)')
    plt.ylabel('Frequency')
    plt.ylim(0,70000)
    plt.xlim(10**2, 10**6.5)
    plt.xscale("log")
    #plt.legend()
    plt.savefig('CNN_distance_from_ChIP-seq_peak.png')
    

    return [CNN_pos_n, CNN_neg_n]


def plot_CNN_pos_and_PWM_pos_histgram(PWM_positive_distance_list,CNN_positive_distance_list):
    fig = plt.figure()
    ax = fig.add_subplot(1,1,1)
    bins = np.logspace(0,10, num=50)

    ax.set_title('Distance to the nearest ChIP-seq peak center')
    # reference: https://qiita.com/ShoheiKojima/items/fa5128c14c8365a7b89c
    PWM_pos_n, pos_bins, _ = ax.hist(x=PWM_positive_distance_list,label='PWM-positive',bins=bins,alpha=0.3,color='grey')
    CNN_pos_n, pos_bins, _ = ax.hist(x=CNN_positive_distance_list,label='CNN-positive',bins=bins,alpha=0.3,color='tab:orange')
    plt.ylim(0,70000)
    plt.xlabel('Distance (bp)')
    plt.ylabel('Frequency')
    plt.xlim(10**2, 10**6.5)
    plt.xscale("log")
    #plt.legend()
    plt.savefig('PWM_pos_distance_and_CNN_pos_dictance.png')
    

    return 0


def plot_PWM_histgram(PWM_positive_distance_list,PWM_negative_distance_list):
    fig = plt.figure()
    ax = fig.add_subplot(1,1,1)
    bins = np.logspace(0,10, num=50)
    
    #ax.set_title('Distance to the nearest ChIP-seq peak center')
    # reference: https://qiita.com/ShoheiKojima/items/fa5128c14c8365a7b89c
    PWM_neg_n, pos_bins, _ = ax.hist(x=PWM_negative_distance_list,label='PWM-negative',bins=bins,alpha=0.3)
    PWM_pos_n, pos_bins, _ = ax.hist(x=PWM_positive_distance_list,label='PWM-positive',bins=bins,alpha=0.3)
    plt.ylim(0,70000)
    plt.xlabel('Distance (bp)')
    plt.ylabel('Frequency')
    plt.xlim(10**2, 10**6.5)
    plt.xscale("log")
    #plt.legend()
    plt.savefig('PWM_pos_distance_from_ChIP-seq.png')


    return 0


if __name__=='__main__':
    CNN_distance_dict = json.load(open('../CNN_dir/CNN_distance_dict.json'))
    PWM_distance_dict = json.load(open('../PWM_dir/global_comp_each_Noverlap_calc_at_34/PWM_distance_dict.json'))
    CNN_pos_distances = CNN_distance_dict['CNN_pos_distance']
    CNN_neg_distances = CNN_distance_dict['CNN_neg_distance']
    PWM_pos_distances = PWM_distance_dict['PWM_pos_distance']
    PWM_neg_distances = PWM_distance_dict['PWM_neg_distance']

    plot_CNN_histgram(CNN_positive_distance_list=CNN_pos_distances,
                      CNN_negative_distance_list=CNN_neg_distances)
    plot_PWM_histgram(PWM_positive_distance_list=PWM_pos_distances,
                      PWM_negative_distance_list=PWM_neg_distances)
    plot_CNN_pos_and_PWM_pos_histgram(PWM_positive_distance_list=PWM_pos_distances,\
                                      CNN_positive_distance_list=CNN_pos_distances)
