import numpy as np
from sklearn.model_selection import train_test_split
import gzip as gz
import glob
import scipy.stats
import random


def load_fasta_gz(f_name):
    sequences = []
    cur_string = ""
    s = 0
    with gz.open(f_name) as fasta_file:
        for line in fasta_file:
            line = line.decode("ascii")
            if line[0] == '>':
                s+=1
                if cur_string:
                    assert len(cur_string) ==301
                    sequences.append(cur_string)

                cur_string = ""
            else:
                line = line.strip()
                cur_string += line

        assert len(cur_string) ==301
        sequences.append(cur_string)


    return sequences


def bernoulli_extraction(probability_of_extract, original_list):
    bernoulli_flags = scipy.stats.bernoulli.rvs(probability_of_extract, size=len(original_list))
    new_list = []
    extracted_list_from_original_list = []
    
    for list_index, flag in enumerate(bernoulli_flags):
        if flag == 1:
            new_list.append(original_list[list_index])
        elif flag == 0:
            extracted_list_from_original_list.append(original_list[list_index])

    assert len(new_list)+len(extracted_list_from_original_list)==len(original_list) 

    return [extracted_list_from_original_list, new_list]


def datasplit4AUROC(hot_object, cold_object):
    sampled_hot_object_indices = []
    X_test_hot = []
    hot_object_len_b4_processed = len(hot_object)
    index_values = random.sample(list(enumerate(hot_object)), round(len(hot_object)/10))
    for index, hot_value in index_values:
        sampled_hot_object_indices.append(index)
        X_test_hot.append(hot_value)

    hot_object = np.array(hot_object)
    hot_object = np.delete(hot_object, sampled_hot_object_indices)
    X_train_hot = hot_object.tolist()
    assert round((len(X_train_hot)+len(X_test_hot))/hot_object_len_b4_processed)==1
    assert round(len(set(X_train_hot) ^ set(X_test_hot))/(len(X_train_hot)+len(X_test_hot)))==1, len(set(X_train_hot) ^ set(X_test_hot))/(len(X_train_hot)+len(X_test_hot))

    X_train_cold, X_test_cold  = train_test_split(cold_object, test_size=len(X_test_hot)*49)
    print("length of X_test_hot: ", len(X_test_hot))
    print("length of X_test_cold: ", len(X_test_cold))
    print("length of X_train_hot: ", len(X_train_hot))
    print("length of X_train_cold: ", len(X_train_cold))

    return [X_train_hot, X_train_cold, X_test_hot, X_test_cold]


if __name__=="__main__":
    print("hello from datasplit4AUROC.py")
