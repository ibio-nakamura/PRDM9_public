import sys
import pandas as pd
import random
from Bio import SeqIO 
from tqdm import tqdm
from collections import OrderedDict
import numpy as np
import time

from datasplit4AUROC import datasplit4AUROC
from make_auged_train_data_vs_ChIP_modules import peak_seq_maker, seq_maker, make_original_hot_data, make_original_hot_od_narrow, \
                                                  extract_cold_data_with_min_separation_distance, make_training_files, data_split, \
                                                  peak_allocation_augmentation_for_narrow_seq


def main(chr_index, MAX_AUG_TIMES, SEQ_LEN, MIN_SEP_DISTANCE):
    peak_fragments = peak_seq_maker(file_name='GSE99407_ChIPseq_Peaks.YFP_HumanPRDM9.antiGFP.protocolN.p10e-5.sep250.Annotated.txt.gz',\
                                    chr_index=chr_index)
    seq = seq_maker(chr_index=chr_index, PATH='../../make_Noverlap_fragments/hg19/')
    # original_hot_od has format like {pos1:'ATGCATGC...', pos2:...}.
    original_hot_od = make_original_hot_data(peak_seq_list=peak_fragments, seq=seq)
    print("# of the ChIP-seq peak at chr{0}: ".format(chr_index), len(original_hot_od))
    hot_od = make_original_hot_od_narrow(original_hot_od=original_hot_od,seq_len=SEQ_LEN)

    cold_od = extract_cold_data_with_min_separation_distance(original_hot_od=original_hot_od, seq=seq, augtimes=8,\
                                                             MIN_SEP_DISTANCE=MIN_SEP_DISTANCE, fragment_len=SEQ_LEN)
    
    print("Now, splitting data...")
    # note: they are keys not fragments.
    X_the_rest_hot_pos, X_the_rest_cold_pos, X_test_hot_pos, X_test_cold_pos = data_split(hot_od, cold_od)

    assert len(X_the_rest_hot_pos)+len(X_test_hot_pos)==len(hot_od)
    assert len(X_the_rest_cold_pos)+len(X_test_cold_pos)==len(cold_od)
    
    X_train_hot_original = [hot_od[pos] for pos in X_the_rest_hot_pos]
    assert len(X_train_hot_original[0]) == SEQ_LEN
    X_train_hot_allocated = peak_allocation_augmentation_for_narrow_seq(seq=seq, data_pos_list=X_the_rest_hot_pos, aug_times=1, seq_len=SEQ_LEN)
    assert len(X_the_rest_hot_pos)*1 == len(X_train_hot_allocated), "{0}=!{1}".format(str(len(X_the_rest_hot_pos)*1),str(len(X_train_hot_allocated)))
    X_train_hot_3aug = peak_allocation_augmentation_for_narrow_seq(seq=seq, data_pos_list=X_the_rest_hot_pos, aug_times=MAX_AUG_TIMES, seq_len=SEQ_LEN)
    assert len(X_the_rest_hot_pos)*3 == len(X_train_hot_3aug), "{0}=!{1}".format(str(len(X_the_rest_hot_pos)*3),str(len(X_train_hot_3aug)))
    X_test_hot = peak_allocation_augmentation_for_narrow_seq(seq=seq, data_pos_list=X_test_hot_pos, aug_times=1, seq_len=SEQ_LEN)
    assert len(X_test_hot_pos) == len(X_test_hot)

    X_test_cold = [cold_od[cold_pos] for cold_pos in X_test_cold_pos]
    X_train_cold = [cold_od[cold_pos] for cold_pos in X_the_rest_cold_pos]
    X_train_cold_for_allocated = random.sample(X_train_cold, len(X_train_hot_allocated))
    X_train_cold_for_original = random.sample(X_train_cold, len(X_train_hot_original))
    X_train_cold_for_3aug = random.sample(X_train_cold, len(X_train_hot_3aug))
    
    #directory names where each file is stocked
    train_test_fastas_dir = './{0}bp_train_test_fastas_dir/'.format(SEQ_LEN)
    # write test sequences.
    print(make_training_files(hotspots=X_test_hot,coldspots=X_test_cold,\
          out_hot_fname=(train_test_fastas_dir+"{0}bp_positive_test_chr"+str(chr_index)+".fasta").format(str(SEQ_LEN)),\
          out_cold_fname=(train_test_fastas_dir+"{0}bp_negative_test_chr"+str(chr_index)+".fasta").format(str(SEQ_LEN))))
    # write training sequences.
    print(make_training_files(hotspots=X_train_hot_original,coldspots=X_train_cold_for_original,\
          out_hot_fname=(train_test_fastas_dir+"{0}bp_positive_train_original_chr"+str(chr_index)+".fasta").format(str(SEQ_LEN)),\
          out_cold_fname=(train_test_fastas_dir+"{0}bp_negative_train_original_chr"+str(chr_index)+".fasta").format(str(SEQ_LEN))))
    print(make_training_files(hotspots=X_train_hot_allocated,coldspots=X_train_cold_for_allocated,\
          out_hot_fname=(train_test_fastas_dir+"{0}bp_positive_train_allocated_chr"+str(chr_index)+".fasta").format(str(SEQ_LEN)),\
          out_cold_fname=(train_test_fastas_dir+"{0}bp_negative_allocated_chr"+str(chr_index)+".fasta").format(str(SEQ_LEN))))
    print(make_training_files(hotspots=X_train_hot_3aug,coldspots=X_train_cold_for_3aug,\
          out_hot_fname=(train_test_fastas_dir+"{0}bp_positive_train_3aug_chr"+str(chr_index)+".fasta").format(str(SEQ_LEN)),\
          out_cold_fname=(train_test_fastas_dir+"{0}bp_negative_train_3aug_chr"+str(chr_index)+".fasta").format(str(SEQ_LEN))))

    return 0


if __name__ == "__main__":
    MAX_AUG_TIMES = 3
    SEQ_LEN = 100
    MIN_SEP_DISTANCE = 1000
    except_list = []
    for chr_index in [22,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,"X"]:
        main(chr_index, MAX_AUG_TIMES, SEQ_LEN, MIN_SEP_DISTANCE)
