# coding: utf-8

import numpy as np
import types
import glob
from tqdm import tqdm
from collections import OrderedDict
import json

from data_utils import load_fasta_gz, load_fasta_gz_no_assert, load_fasta_gz_and_return_OrderedDict
from data_utils_allocated import load_model_yaml, one_hot, reverse_complement


def predict2bed(predictions, mc_predictions, annotation_list, chr_index,input_len):
    dir = './Noverlap_predictions_bed/'
    out_fname = "CNN_prediction_Noverlap_3aug_chr_"+chr_index+".bed"
    with open(dir+out_fname, "w") as f:
        f.write("seq\t"+"start_pos\t"+"end_pos\t"+"prediction_probability\t"+"mc_prediction_probability\n")
        for i, annotation in enumerate(annotation_list):
            annotation = annotation.replace(' <unknown description>','')
            splited_annotation = annotation.split('FragmentStartsFrom')
            chr = splited_annotation[0]
            start_pos = int(splited_annotation[1])
            f.write(str(chr)+'\t'+str(start_pos)+'\t'+str(start_pos+(input_len-1))+'\t'+str(predictions[i][1])+'\t'+str(mc_predictions[i][1])+'\n')

    return 0


def predict_mc(self, X_pred, n_preds=100):
    return np.mean([self.predict(X_pred) for i in range(n_preds)], axis=0)


def main(input_len,chr_index):
    loaded_model = load_model_yaml("SavedModel_100bp_3aug")
    loaded_model.predict_mc = types.MethodType(predict_mc, loaded_model)
    loaded_model.summary()
    index_sequence_od = OrderedDict()

    dir_name = '../make_Noverlap_fragments/100bp_Noverlap_fastas/'
    gzip_file_name = '100bp_NoverlapChr'+chr_index+'.fasta.gz'
    current_chr_index_sequence_od = load_fasta_gz_and_return_OrderedDict(dir_name+gzip_file_name,input_len)
    for key, value in current_chr_index_sequence_od.items():
        index_sequence_od[key]=value

    cleanged_annotation_list = []
    cleanged_sequences = []
    fasta_annotations = [key for key in index_sequence_od]

    for fasta_annotation in fasta_annotations:
        sequence = index_sequence_od[fasta_annotation]

        if 'N' in sequence:
            del index_sequence_od[fasta_annotation]
            continue

        cleanged_annotation_list.append(fasta_annotation)
        cleanged_sequences.append(sequence)

    print("# of data in {0} :{1}".format(str(chr_index),str(len(index_sequence_od))))

    X = np.array([one_hot(seq) for seq in cleanged_sequences])[:,:-1]
    mc_predictions = loaded_model.predict_mc(X)
    predictions = loaded_model.predict(X)

    initial_pos = 0
    zero = predict2bed(predictions=predictions, mc_predictions=mc_predictions, annotation_list=cleanged_annotation_list, chr_index=chr_index, input_len=input_len)


if __name__ == '__main__':
    input_len=100
    chr_indices = [str(i) for i in range(1,23)]
    chr_indices.append('X')
    for chr_index in chr_indices:
        main(input_len, chr_index)
