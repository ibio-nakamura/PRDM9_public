import math
import json
import numpy as np
import pandas as pd
import pyranges as pr
from tqdm import tqdm
import matplotlib.pyplot as plt
from scipy import stats
import sys
from collections import OrderedDict


def ave(rec_list):
    if len(rec_list) == 0:
        return np.nan
    else:
        return sum(rec_list)/len(rec_list)

def hot_cold_dict_maker(tsv_fname,chr_index):
    #-> returned OrderedDict format is like [((chr1, 301, 'hot'),0.999)...] 
    df = pd.read_csv(tsv_fname, delimiter='\t')
    od = OrderedDict()
    for which_seq in ['hotseq', 'coldseq']:
        focused_df = df[df['chr']==which_seq+'_chr'+str(chr_index)]
        start_pos = list(focused_df['start_pos'])
        probability_score = list(focused_df['mc_prediction_probability'])
        if which_seq == 'hotseq':
            for i, pos in enumerate(start_pos):
                key = ('chr'+chr_index, str(pos), 'hot')
                od[key] = probability_score[i]
        if which_seq == 'coldseq':
            for i, pos in enumerate(start_pos):
                key = ('chr'+chr_index, str(pos), 'cold')
                od[key] = probability_score[i]
    return od


def Noverlap_hot_cold_dict_maker(tsv_fname, hot_cold_judged_fname, chr_index):
    od = OrderedDict()
    # opening bed file which has information of start pos and prediction probability.
    df = pd.read_csv(tsv_fname, delimiter='\t')
    start_pos_list = list(df['start_pos'])
    probability_score_list = list(df['mc_prediction_probability'])
    assert len(start_pos_list) == len(probability_score_list)
    # opening json file which has information each fragment has a peak(1) or not(0).
    json_open = open(hot_cold_judged_fname)
    hot_cold_judged_dict = json.load(json_open)
    
    #positionでソートしておく。
    start_pos_list.sort()
    for i, pos in enumerate(start_pos_list):
        judgement = hot_cold_judged_dict[str(pos)]
        if judgement==1:
            key = ('chr'+chr_index, str(pos), 'hot')
            od[key] = probability_score_list[i]
        elif judgement==0:
            key = ('chr'+chr_index, str(pos), 'cold')
            od[key] = probability_score_list[i]

    return od


def Noverlap_PWM_hot_cold_dict_maker(PWM_score_fname, hot_cold_judged_fname, chr_index):
    od = OrderedDict()
    # opening json file which has PWM max-score.
    json_open = open(PWM_score_fname)
    json_dict = json.load(json_open)
    # opening json file which has information each fragment has a peak(1) or not(0).
    json_open = open(hot_cold_judged_fname)
    hot_cold_judged_dict = json.load(json_open)

    # fragment index is like "Chr1FragmentStartsFrom10234 <unknown description"
    for fragment_index, score in json_dict.items():
        splited_fragment_index = fragment_index.split()[0].split('FragmentStartsFrom')
        index_chr_index = splited_fragment_index[0].replace('Chr','')
        index_start_pos = splited_fragment_index[1]
        assert index_chr_index == chr_index, str(index_chr_index)+'≠'+chr_index
        
        judgement = hot_cold_judged_dict[str(index_start_pos)]
        if judgement==1:
            key = ('chr'+chr_index, str(index_start_pos), 'hot')
        else:
            key = ('chr'+chr_index, str(index_start_pos), 'cold')

        od[key] = score
    return od


'''
def Noverlap_make_rec_chr_dict(path,chr_index):
    fname = 'Noverlap_recombination_chr_'+chr_index+'_CEU.json'
    jopen = open(path+fname)
    rec_dict = json.load(jopen)
    print('N of fragments ', len(rec_dict))

    # rec_chr_dict is modified rec_dict has format of {(pos, chr_index):rec_rate}
    rec_chr_dict = {}
    for pos, rec_rate in rec_dict.items():
        new_key = (pos, chr_index)
        rec_chr_dict[new_key] = rec_rate


    return rec_chr_dict
'''

#{1st percentile:[rec, rec,..],2st percentile:[rec,..]...}みたいな辞書を作ってくれる
def sort_and_make_lists(all_score_dict, all_rec_dict):
    info_list = []
    rec_list = []
    score_list = []
    # dictionary is sorted by scores.
    score_sorted = sorted(all_score_dict.items(), key=lambda x:x[1])

    for kvtupple in reversed(score_sorted):
        # key has 3 items within its tupple.; OrderedDict format is like [((chr1, 301, 'hot'),0.999)...]
        key = kvtupple[0]
        key_chr = str(key[0]).replace('chr','')
        key_pos = key[1]
        key_which_seq = str(key[2])
        score_value = kvtupple[1]
        
        key4rec_list = (key_pos, key_chr)
        try:
            rec_list.append(all_rec_dict[key4rec_list])
            info_list.append(key)
            score_list.append(score_value)
        except:
            print(str(key4rec_list)+"のキーエラーと思われる。")
            continue
        
    assert len(info_list)==len(rec_list)
    assert len(info_list)==len(score_list)

    return [info_list, rec_list, score_list]


def make_2by2_table_by_threshold(threshold, info_list, rec_list, score_list):
    pos_hot_rec = []
    pos_cold_rec = []
    neg_hot_rec = []
    neg_cold_rec = []
    binary_list = [1 if score>threshold else 0 for score in score_list]
    
    # check it to confirm being appropriately sorted or not.
    #print(binary_list[:100])
    #print('...')
    #print(binary_list[-100:])

    # info_list has tupples like (chr1, 301, 'hot').
    for index, binary in enumerate(binary_list):
        which_seq = info_list[index][2]
        rec_rate = rec_list[index]
        # if the model predict it is positive
        if binary == 1:
            if which_seq=='hot':
                pos_hot_rec.append(rec_rate)
            elif which_seq=='cold':
                pos_cold_rec.append(rec_rate)
        # if the model predict it is negative
        else:
            if which_seq=='hot':
                neg_hot_rec.append(rec_rate)
            elif which_seq=='cold':
                neg_cold_rec.append(rec_rate)
    
    n_table = np.array([len(pos_hot_rec), len(neg_hot_rec), len(pos_cold_rec), len(neg_cold_rec)])
    table = np.array([ave(pos_hot_rec), ave(neg_hot_rec), ave(pos_cold_rec), ave(neg_cold_rec)])
    n_table.reshape(2,2)
    table.reshape(2,2)
    all_cold_rec = pos_cold_rec + neg_cold_rec
    all_hot_rec = pos_hot_rec + neg_hot_rec
    print('average of all ChIP-seq: {0}'.format(ave(all_hot_rec)))
    print('average of all non ChIP-seq fragment: {0}'.format(ave(all_cold_rec)))
    print('column: pos&hot ','neg&hot', 'pos&cold ', 'neg&cold' )
    print('samples: {0}'.format(n_table))
    
    return table


def make_2by4_table_by_percentage(top_percentage, info_list, rec_list, score_list, PWM_info_list, PWM_rec_list, PWM_score_list):
    pos_hot_rec = []
    pos_cold_rec = []
    neg_hot_rec = []
    neg_cold_rec = []
    PWM_pos_hot_rec = []
    PWM_pos_cold_rec = []
    PWM_neg_hot_rec = []
    PWM_neg_cold_rec = []

    # The binary_list is used in DLscores and PWMscores sharely.
    total_sample_n = len(score_list)
    n_of_ones = int((top_percentage/100)*total_sample_n)
    binary_list = [1]*n_of_ones + [0]*(total_sample_n-n_of_ones)

    # check it to confirm being appropriately sorted or not.
    # print(binary_list[:100])
    # print('...')
    # print(binary_list[-100:])

    # info_list has tupples like (chr1, 301, 'hot').
    for index, binary in enumerate(binary_list):
        which_seq = info_list[index][2]
        PWM_which_seq = PWM_info_list[index][2]
        rec_rate = rec_list[index]
        PWM_rec_rate = PWM_rec_list[index]

        # if the model predict it is positive
        if binary == 1:
            if which_seq=='hot':
                pos_hot_rec.append(rec_rate)
            elif which_seq=='cold':
                pos_cold_rec.append(rec_rate)
            if PWM_which_seq == 'hot':
                PWM_pos_hot_rec.append(PWM_rec_rate)
            elif PWM_which_seq == 'cold':
                PWM_pos_cold_rec.append(PWM_rec_rate)
        # if the model predict it is negative
        else:
            if which_seq=='hot':
                neg_hot_rec.append(rec_rate)
            elif which_seq=='cold':
                neg_cold_rec.append(rec_rate)
            if PWM_which_seq == 'hot':
                PWM_neg_hot_rec.append(PWM_rec_rate)
            elif PWM_which_seq == 'cold':
                PWM_neg_cold_rec.append(PWM_rec_rate)
    
    n_table = np.array([len(pos_hot_rec), len(neg_hot_rec), len(pos_cold_rec), len(neg_cold_rec), len(PWM_pos_hot_rec), len(PWM_neg_hot_rec), len(PWM_pos_cold_rec), len(PWM_neg_cold_rec)])
    table = np.array([ave(pos_hot_rec), ave(neg_hot_rec), ave(pos_cold_rec), ave(neg_cold_rec), ave(PWM_pos_hot_rec), ave(PWM_neg_hot_rec), ave(PWM_pos_cold_rec), ave(PWM_neg_cold_rec)])
    all_cold_rec = pos_cold_rec + neg_cold_rec
    all_hot_rec = pos_hot_rec + neg_hot_rec
    print('top '+str(top_percentage)+'%')
    print('average of all ChIP-hot: {0}'.format(ave(all_hot_rec)))
    print('average of all ChIP-cold: {0}'.format(ave(all_cold_rec)))
    print('')
    print('<average rec rate table>')
    print('column    {0}\t{1}\t{2}\t{3}'.format('DLpos    ', 'PWMpos    ', 'DLneg    ', 'PWMneg    '))
    print('ChIP-hot  {0:.3e}\t{1:.3e}\t{2:.3e}\t{3:.3e}'.format(table[0],table[4],table[1],table[5]))
    print('ChIP-cold {0:.3e}\t{1:.3e}\t{2:.3e}\t{3:.3e}'.format(table[2],table[6],table[3],table[7]))
    print('total ave {0:.3e}\t{1:.3e}\t{2:.3e}\t{3:.3e}'.format(ave(pos_hot_rec+pos_cold_rec), ave(PWM_pos_hot_rec+PWM_pos_cold_rec), ave(neg_hot_rec+neg_cold_rec), ave(PWM_neg_hot_rec+PWM_neg_cold_rec)))
    print('')
    print('<sample number table>')
    print('column    {0}\t{1}\t{2}\t{3}'.format('DLpos', 'PWMpos', 'DLneg', 'PWMneg'))
    print('ChIP-hot  {0}\t{1}\t{2}\t{3}'.format(n_table[0],n_table[4],n_table[1],n_table[5]))
    print('ChIP-cold {0}\t{1}\t{2}\t{3}'.format(n_table[2],n_table[6],n_table[3],n_table[7]))
    print('total num {0}\t{1}\t{2}\t{3}'.format(n_table[0]+n_table[2], n_table[4]+n_table[6], n_table[1]+n_table[3], n_table[5]+n_table[7]))

    return table


def make_2by4_table_by_percentage_return_raw_table(top_percentage, info_list, rec_list, score_list, PWM_info_list, PWM_rec_list, PWM_score_list):
    pos_hot_rec = []
    pos_cold_rec = []
    neg_hot_rec = []
    neg_cold_rec = []
    PWM_pos_hot_rec = []
    PWM_pos_cold_rec = []
    PWM_neg_hot_rec = []
    PWM_neg_cold_rec = []

    # The binary_list is used in DLscores and PWMscores sharely.
    total_sample_n = len(score_list)
    n_of_ones = int((top_percentage/100)*total_sample_n)
    binary_list = [1]*n_of_ones + [0]*(total_sample_n-n_of_ones)

    # info_list has tupples like (chr1, 301, 'hot').
    for index, binary in enumerate(binary_list):
        which_seq = info_list[index][2]
        PWM_which_seq = PWM_info_list[index][2]
        rec_rate = rec_list[index]
        PWM_rec_rate = PWM_rec_list[index]

        # if the model predict it is positive
        if binary == 1:
            if which_seq=='hot':
                pos_hot_rec.append(rec_rate)
            elif which_seq=='cold':
                pos_cold_rec.append(rec_rate)
            if PWM_which_seq == 'hot':
                PWM_pos_hot_rec.append(PWM_rec_rate)
            elif PWM_which_seq == 'cold':
                PWM_pos_cold_rec.append(PWM_rec_rate)
            
        # if the model predict it is negative
        else:
            if which_seq=='hot':
                neg_hot_rec.append(rec_rate)
            elif which_seq=='cold':
                neg_cold_rec.append(rec_rate)
            if PWM_which_seq == 'hot':
                PWM_neg_hot_rec.append(PWM_rec_rate)
            elif PWM_which_seq == 'cold':
                PWM_neg_cold_rec.append(PWM_rec_rate)
    
    raw_table = [pos_hot_rec, neg_hot_rec, pos_cold_rec, neg_cold_rec, PWM_pos_hot_rec, PWM_neg_hot_rec, PWM_pos_cold_rec, PWM_neg_cold_rec]


    return raw_table
