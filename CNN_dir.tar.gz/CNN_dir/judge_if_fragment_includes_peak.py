import sys

from collections import OrderedDict
import json
import pandas as pd
from tqdm import tqdm
from Bio import SeqIO

sys.path.append('./100bp_seqs')
from make_auged_train_data_vs_ChIP_modules import make_original_hot_data, seq_maker, peak_seq_maker
from data_utils import load_fasta_gz


def PWM_dict_maker(fname, chr_index):
    ret_od = OrderedDict()
    jopen = open(fname)
    original_dict = json.load(jopen)
    for start_key, value in original_dict.items():
        ret_od[(str(start_key.replace('FragmentStartsFrom','')),chr_index)] = value

    return ret_od


#DLはbed形式でスコアが保存されている。
def CNN_dict_maker(CNN_fname, chr_index):
    df = pd.read_csv(CNN_fname, delimiter='\t')
    start_pos_list = list(df['start_pos'])
    score_list = list(df['mc_prediction_probability'])

    ret_dict = OrderedDict()
    for start, score in zip(start_pos_list, score_list):
        ret_dict[(str(start),chr_index)] = score

    return ret_dict


# ChIP_peak_dict<- {pos1:'ATCG...GCTA', pos2:'ATGC...GTCA', ....}
# Noverlap_score_dict <- {(str(start),chr_index):score,...}
def judge_if_fragment_includes_peak_region(chr_index,  ChIP_peak_dict, peak_range, fragment_len):
    #assert peak_range%2 == 1
    ret_dict =  OrderedDict()
    ChIP_peak_list = sorted([ChIP_pos for ChIP_pos in ChIP_peak_dict])
    Noverlap_sequences = load_fasta_gz(f_name="../make_Noverlap_fragments/100bp_Noverlap_fastas/100bp_NoverlapChr{0}.fasta.gz".format(chr_index), \
                                       input_len=fragment_len)
    Noverlap_pos_key_list = sorted([100*i for i in range(len(Noverlap_sequences))])

    for ChIP_peak in tqdm(ChIP_peak_list):
        peak_center = ChIP_peak+150
        ChIP_peak_range_start = int(peak_center-(peak_range/2))+1
        ChIP_peak_range_end = int(peak_center+(peak_range/2))
        within_peak_range_frag = 0

        for i, key in enumerate(Noverlap_pos_key_list):
            Noverlap_fragment_start_pos = key
            Noverlap_fragment_end_pos = Noverlap_fragment_start_pos + (fragment_len-1)

            if not(within_peak_range_frag):
                # Noverlap_fragment_end_pos get within ChIP_peak_range first time.
                if ChIP_peak_range_start <= Noverlap_fragment_end_pos:
                    ret_dict[Noverlap_fragment_start_pos] = 1
                    within_peak_range_frag = 1
            else:
                # While start of fragment is before end of peak range, the fragment gets 1.
                if Noverlap_fragment_start_pos <= ChIP_peak_range_end:
                    ret_dict[Noverlap_fragment_start_pos]=1
                else:
                    break
    # Finally, all keys which don't have 1, automatically its value = 0.
    for key in Noverlap_pos_key_list:
        if not(key in ret_dict):
            ret_dict[key] = 0


    return ret_dict


if __name__ == '__main__':
    for chr_index in range(1,23):
    #for chr_index in [str(22)]:
        chr_index = str(chr_index)
        peak_fragments = peak_seq_maker(file_name='./100bp_seqs/GSE99407_ChIPseq_Peaks.YFP_HumanPRDM9.antiGFP.protocolN.p10e-5.sep250.Annotated.txt.gz', chr_index=chr_index)
        seq = seq_maker(chr_index=chr_index, PATH='../make_Noverlap_fragments/hg19/')
        ChIP_peak_dict = make_original_hot_data(peak_fragments, seq)
        # ChIP_peak_dict: {pos1:'ATCG...GCTA', pos2:'ATGC...GTCA', ....}
        judged_dict = judge_if_fragment_includes_peak_region(chr_index=chr_index, ChIP_peak_dict=ChIP_peak_dict, peak_range=301, fragment_len=100)
        dir = './peak_judgement_out/'
        with open(dir+'judged_chr_{0}.json'.format(chr_index), 'w') as f:
            json.dump(judged_dict, f, indent=4)
    
