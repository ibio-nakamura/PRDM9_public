import types
import glob
import pandas as pd
from sklearn import metrics
import matplotlib.pyplot as plt
from keras.utils import to_categorical
import keras
import random
import numpy as np
import re
import os

import docopt
from keras.layers import Conv1D, GlobalMaxPool1D, Dense, Dropout, MaxPool1D
from keras.optimizers import Adam, SGD
from keras.initializers import Constant
import keras.backend as K
from keras.engine.topology import Layer
from core import MotifMirrorGradientBleeding, CustomSumPool, MCRCDropout
from keras.models import Sequential
from keras.callbacks import EarlyStopping
import tflearn
from keras.models import Model
from keras.layers import GlobalMaxPool1D, GaussianDropout, Lambda
from keras.regularizers import l2
from sklearn.metrics import roc_auc_score
import gzip as gz
import types
from keras.layers import BatchNormalization
from sim_train import augment_data
import json
from keras.layers import BatchNormalization, LeakyReLU
import optuna

from data_utils import load_fasta_gz, load_fasta_gz_no_assert
from data_utils_allocated import load_model_yaml, one_hot, train_test_val_split, reverse_complement


def load_recomb_data_for_hyperparameter_search(aug, input_len):
    hot_sequences = []
    cold_sequences = []
    for chr_index in [str(1),str(2),str(3),str(4),str(5),str(6),str(7),str(8),str(9),str(10),str(11),str(12),str(13),str(14),str(15),str(16),str(17),str(18),str(19),str(20),str(21),str(22),'X']:
    #for chr_index in [str(22)]:
        current_chr_hot_sequences = load_fasta_gz(f_name="./100bp_seqs/100bp_train_test_fastas_dir/100bp_hotspots_train_original_chr"+chr_index+".fasta.gz",\
                                                  input_len=input_len)
        #データ量を1/10に減らす。
        current_chr_hot_sequences = current_chr_hot_sequences[:len(current_chr_hot_sequences)//10]        
        hot_sequences += current_chr_hot_sequences
        
        current_chr_cold_sequences = load_fasta_gz(f_name="./100bp_seqs/100bp_train_test_fastas_dir/100bp_coldspots_train_original_chr"+chr_index+".fasta.gz", \
                                                   input_len=input_len)
        #データ量を1/10に減らす。
        current_chr_cold_sequences = current_chr_cold_sequences[:len(current_chr_cold_sequences)//10]
        cold_sequences += current_chr_cold_sequences        

    print("N of hot seqs: ", len(hot_sequences))
    print("N of cold seqs: ", len(cold_sequences))

    X = np.array([one_hot(seq) for seq in hot_sequences] + [one_hot(seq) for seq in cold_sequences])[:,:input_len] # to make the pooling symmetric 
    Y = np.array([1]*len(hot_sequences) + [0]*len(cold_sequences))


    X_train, X_val, X_test, Y_train, Y_val, Y_test = train_test_val_split(X, Y)

    return X_train, X_val, X_test, Y_train, Y_val, Y_test


def load_recomb_data(aug, input_len):
    hot_sequences = []
    cold_sequences = []
    for chr_index in [str(1),str(2),str(3),str(4),str(5),str(6),str(7),str(8),str(9),str(10),str(11),str(12),str(13),str(14),str(15),str(16),str(17),str(18),str(19),str(20),str(21),str(22),'X']:
    #for chr_index in [str(22)]:
        current_chr_hot_sequences = load_fasta_gz_no_assert(f_name="./100bp_seqs/100bp_train_test_fastas_dir/100bp_hotspots_train_original_chr"+chr_index+".fasta.gz")
        hot_sequences += current_chr_hot_sequences
        
        current_chr_cold_sequences = load_fasta_gz_no_assert(f_name="./100bp_seqs/100bp_train_test_fastas_dir/100bp_coldspots_train_original_chr"+chr_index+".fasta.gz")
        cold_sequences += current_chr_cold_sequences

    print("N of hot seqs: ", len(hot_sequences))
    print("N of cold seqs: ", len(cold_sequences))

    X = np.array([one_hot(seq) for seq in hot_sequences] + [one_hot(seq) for seq in cold_sequences])[:,:-1] # to make the pooling symmetric(10/16) 
    Y = np.array([1]*len(hot_sequences) + [0]*len(cold_sequences))


    X_train, X_val, X_test, Y_train, Y_val, Y_test = train_test_val_split(X, Y)

    return X_train, X_val, X_test, Y_train, Y_val, Y_test


def predict_mc(self, X_pred, n_preds=100):
    return np.mean([self.predict(X_pred) for i in range(n_preds)], axis=0)



def generate_model(
        input_len, epochs, nn_params, filter_num, \
        first_filter_length, \
        internal_conv_N ,internal_filter_length, pool_size, \
        activation, given_lrate, reg, dropout_rate, \
        batch_size, optimizer): 

    bigger_model = Sequential()
    input_height = 4
    input_length = input_len
    if activation=='lrelu':
        bigger_model = Sequential()
        input_height = 4
        input_length=input_len
        bigger_model.add(Conv1D(input_shape=(input_length, input_height), #but one channel in the one hot encoding of the genome
                                filters=filter_num,
                                kernel_size=first_filter_length,
                                strides=1,
                                padding="valid",
                                kernel_regularizer=l2(reg)
                            ))
        # とりあえず今回、LeakyReLUのパラメータは無視。
        bigger_model.add(LeakyReLU(alpha=0.01))
    else:
        bigger_model.add(Conv1D(input_shape=(input_length, input_height), #but one channel in the one hot encoding of the genome
                                filters=filter_num,
                                kernel_size=first_filter_length,
                                strides=1,
                                padding="valid",
                                activation=activation,
                                kernel_regularizer=l2(reg)
                            ))

    if nn_params["batch_norm"]:
        bigger_model.add(BatchNormalization())

    if nn_params["use_dropout"]:
         if nn_params["mc_dropout"]:
              if nn_params["apply_rc"]:
                  bigger_model.add(MCRCDropout(dropout_rate))
              else:
                  bigger_model.add(Lambda(lambda x: K.dropout(x, level=0.1)))
         else:
               bigger_model.add(Dropout(0.1))

    bigger_model.add(MaxPool1D(pool_size=pool_size))


    for i in range(internal_conv_N):
        if activation=='lrelu':
            bigger_model.add(Conv1D(
                             filters=filter_num,
                             kernel_size=internal_filter_length,
                             strides=1,
                             padding="valid",
                             kernel_regularizer=l2(reg)
                            ))
            bigger_model.add(LeakyReLU(alpha=0.01))
        else:
            bigger_model.add(Conv1D(
                                 filters=filter_num,
                                 kernel_size=internal_filter_length,
                                 strides=1,
                                 padding="valid",
                                  activation=activation,
                                 kernel_regularizer=l2(reg)
                                ))

        if nn_params["batch_norm"]:
            bigger_model.add(BatchNormalization())

        if nn_params["use_dropout"]:
             if nn_params["mc_dropout"]:
                  if nn_params["apply_rc"]: 
                      bigger_model.add(MCRCDropout(dropout_rate))
                  else:
                      bigger_model.add(Lambda(lambda x: K.dropout(x, level=0.1)))
             else:
                  bigger_model.add(Dropout(0.1))


    if nn_params["apply_rc"]:
        bigger_model.add(CustomSumPool())
        divisor = 2
    else:
        divisor = 1


    bigger_model.add(GlobalMaxPool1D())

    if nn_params["custom_init"]:
        bigger_model.add(Dense(2, activation="softmax", kernel_initializer=Constant(np.array([[1]*(filter_num//divisor), [1]*(filter_num//divisor)])),
        bias_initializer=Constant(np.array([1, -1]))))
    else:
        bigger_model.add(Dense(2, activation="softmax"))


    #lrate = 0.01
    lrate = given_lrate
    decay = lrate/epochs
    if optimizer=='adam':
        adam = Adam(lr=lrate, beta_1=0.9, beta_2=0.999, epsilon=1e-08, decay=decay)
        bigger_model.compile(loss='categorical_crossentropy', optimizer=adam, metrics=['accuracy'])
    elif optimizer=='sgd':
        # https://keras.io/ja/optimizers/
        sgd = SGD(lr=lrate, momentum=0.0, decay=decay,nesterov=False)
        bigger_model.compile(loss='categorical_crossentropy', optimizer=sgd, metrics=['accuracy'])
    elif optimizer=='momentum':
        momentum_sgd = SGD(lr=lrate, momentum=0.9, decay=decay,nesterov=False)
        # https://docs.w3cub.com/tensorflow~2.3/keras/optimizers/sgd
        # Althought it is a document for tf.keras.
        bigger_model.compile(loss='categorical_crossentropy', optimizer=momentum_sgd, metrics=['accuracy'])

    bigger_model.predict_mc = types.MethodType(predict_mc, bigger_model)
    return bigger_model


def binary_accuracy(y_true, y_pred):
    return np.mean(np.equal(y_true, np.round(y_pred)))


# train関数をobjectiveとして改変。
def objective(trial):
    res = []
    best_acc = 0
    input_len = 100
    val_accs = []
    X_train, X_val, X_test, Y_train, Y_val, Y_test = load_recomb_data_for_hyperparameter_search(False, input_len)
    nn_params={"reg":0.0,"use_dropout":1,"mc_dropout":1,"custom_init":1,"apply_rc":1, "batch_norm":0, "augment_data":0}

    filter_num = trial.suggest_int("filter_num", 2, 100, 2)
    first_filter_length = trial.suggest_int("first_filter_length", 2, 40, 2)
    internal_conv_N = trial.suggest_int("internal_conv_N", 1,3,1)
    internal_filter_length = trial.suggest_int("internal_filter_length", 2,4,1)
    pool_size = trial.suggest_int("pool_size", 2,6,2)
    activation = trial.suggest_categorical("activation", ["elu", "relu", "selu", "lrelu"])
    given_lrate = trial.suggest_loguniform('given_lrate',0.0001,0.1)
    reg = trial.suggest_discrete_uniform("reg",0,0.01,0.0001)
    dropout_rate = trial.suggest_uniform("dropout_rate",0,1)
    batch_size = trial.suggest_categorical("batch_size",[32,64,128,256,512,1024,2048])
    optimizer = trial.suggest_categorical("optimizer",['sgd','momentum','adam'])
    

    print({'filter_num':filter_num, 'first_filter_length':first_filter_length, 'internal_conv_N':internal_conv_N,\
           'internal_filter_length':internal_filter_length, 'pool_size':pool_size, 'activation':activation, \
           'given_lrate':given_lrate, 'reg':reg, 'dropout_rate':dropout_rate, 'batch_size':batch_size, \
           'optimizer':optimizer})

    
    # 最適化の際にoptuna側でも設定するので、n_trialsは消した。
    epochs=20
    model=generate_model(input_len, \
                         epochs, nn_params, filter_num, first_filter_length, \
                         internal_conv_N ,internal_filter_length, pool_size, \
                         activation, given_lrate, reg, dropout_rate, \
                         batch_size, optimizer)
    mm_0 = MotifMirrorGradientBleeding(0,assign_bias=True)
    mm_1 = MotifMirrorGradientBleeding(2,assign_bias=True)
    es = EarlyStopping(monitor='val_acc', patience=4)
    if nn_params["apply_rc"]:
        callbacks=[es, mm_0, mm_1]
    else:
        callbacks=[es]
    model.fit(X_train, tflearn.data_utils.to_categorical(Y_train,2),
          validation_data=(X_val, tflearn.data_utils.to_categorical(Y_val,2)),
          epochs=epochs, batch_size=batch_size, callbacks=callbacks)
    if nn_params["mc_dropout"] and nn_params["use_dropout"]:
        predictions = model.predict_mc(X_test)
    else:
        predictions = model.predict_mc(X_test, n_preds=1)
    acc = binary_accuracy(tflearn.data_utils.to_categorical(Y_test,2), predictions)

    # 最小化したいスコアを返す。
    return 1-acc


def train(input_len, nn_params, n_train_trials, best_params, save_best):
    rocs = []
    res = []
    best_acc = 0
    val_accs = []
    raw = []
    X_train, X_val, X_test, Y_train, Y_val, Y_test = load_recomb_data(False,input_len)
    
    best_filter_num = best_params['filter_num']
    best_first_filter_length = best_params['first_filter_length']
    best_internal_conv_N = best_params['internal_conv_N']
    best_internal_filter_length = best_params['internal_filter_length']
    best_pool_size = best_params['pool_size']
    best_activation = best_params['activation']
    best_given_lrate = best_params['given_lrate']
    best_reg = best_params['reg']
    best_dropout_rate = best_params['dropout_rate']
    best_batch_size = best_params['batch_size']
    best_optimizer = best_params['optimizer']

    for trail in range(n_train_trials):
        epochs=50
        model=generate_model(input_len=input_len, epochs=epochs, nn_params=nn_params, \
                             filter_num=best_filter_num, \
                             first_filter_length=best_first_filter_length, \
                             internal_conv_N=best_internal_conv_N, \
                             internal_filter_length=best_internal_filter_length, \
                             pool_size=best_pool_size, \
                             activation=best_activation, \
                             given_lrate=best_given_lrate, \
                             reg=best_reg, \
                             dropout_rate=best_dropout_rate, \
                             batch_size=best_batch_size, \
                             optimizer=best_optimizer)
        mm_0 = MotifMirrorGradientBleeding(0,assign_bias=True)
        mm_1 = MotifMirrorGradientBleeding(2,assign_bias=True)
        es = EarlyStopping(monitor='val_acc', patience=4)
        if nn_params["apply_rc"]:
            callbacks=[es, mm_0, mm_1]
        else:
            callbacks=[es]

        model.fit(X_train, tflearn.data_utils.to_categorical(Y_train,2),
              validation_data=(X_val, tflearn.data_utils.to_categorical(Y_val,2)),
              epochs=epochs, batch_size=best_batch_size, callbacks=callbacks)

        if nn_params["mc_dropout"] and nn_params["use_dropout"]:
            predictions = model.predict_mc(X_test)
        else:
            predictions = model.predict_mc(X_test, n_preds=1)

        acc = binary_accuracy(tflearn.data_utils.to_categorical(Y_test,2), predictions)
        raw.append((Y_test.tolist(), predictions.tolist()))
        if save_best:
             if acc > best_acc:
                 best_acc = acc
                 from data_utils_allocated import save_model_yaml
                 save_model_yaml(model,"SavedModel_100bp_original")

        res.append(acc)
       
    #with open(nn_params["output_prefix"]+".json","w") as outfile:
    #    json.dump(raw, outfile)


def AUROC(seq_len):
    loaded_model = load_model_yaml("SavedModel_100bp_original")
    loaded_model.predict_mc = types.MethodType(predict_mc, loaded_model)
    loaded_model.summary()

    hot_sequences = []
    cold_sequences = []

    for chr_index in [str(1),str(2),str(3),str(4),str(5),str(6),str(7),str(8),str(9),str(10),str(11),str(12),str(13),str(14),str(15),str(16),str(17),str(18),str(19),str(20),str(21),str(22),'X']:
    #for chr_index in [str(22)]:
        current_chr_hot_sequences = load_fasta_gz_no_assert("./100bp_seqs/100bp_train_test_fastas_dir/100bp_hotspots_test_chr"+chr_index+".fasta.gz")
        hot_sequences += current_chr_hot_sequences
        current_chr_cold_sequences = load_fasta_gz_no_assert("./100bp_seqs/100bp_train_test_fastas_dir/100bp_coldspots_test_chr"+chr_index+".fasta.gz")
        cold_sequences += current_chr_cold_sequences

    X_test = hot_sequences+cold_sequences
    Y_test = [1]*len(hot_sequences)+[0]*len(cold_sequences)
    X_test = np.array([one_hot(seq) for seq in X_test])[:,:-1]#to make pooling symmetric(10/16)
    outputs = loaded_model.predict_mc(X_test)
    y_preds = [output[1]  for output in outputs]

    #~~~~~ここからROCを描く~~~~~~~~
    fpr, tpr, thresholds = metrics.roc_curve(Y_test, y_preds)
    auc = metrics.auc(fpr, tpr)
    print(auc)

    d = {}
    d["fpr"] = fpr.tolist()
    d["tpr"] = tpr.tolist()
    d["thresholds"] = thresholds.tolist()
    with open("AUROC_{0}bp_original.json".format(seq_len),"w") as f:
        json.dump(d,f)
    
    plt.plot(fpr, tpr, label='ROC curve (area = %.4f)'%auc)
    plt.plot(np.linspace(1, 0, len(fpr)), np.linspace(1, 0, len(fpr)), label='Random ROC curve (area = %.2f)'%0.5, linestyle = '--', color = 'gray')

    plt.legend()
    plt.title('ROC curve')
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.grid(True)
    plt.savefig("AUROC_{0}bp_original.png".format(seq_len))


if __name__ == "__main__":
    input_len = 100
    nn_params={"reg":0.0,"use_dropout":1,"mc_dropout":1,"custom_init":1,"apply_rc":1, "batch_norm":0, "augment_data":0}
    n_train_trials = 5
    save_best = 1
    
    study = optuna.create_study()
    study.optimize(objective, n_trials=100)
    best_params = study.best_params
    print('study.best_params: ', best_params)
    with open('best_params_original.json', 'w') as f:
        json.dump(best_params, f, indent=4)
    
    best_params = json.load(open('best_params_original.json'))

    input_len_after_optuna = 99
    train(input_len_after_optuna, nn_params,n_train_trials,best_params,save_best)

    AUROC(seq_len=input_len)
    