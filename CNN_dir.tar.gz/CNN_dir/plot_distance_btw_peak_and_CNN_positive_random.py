from matplotlib import pyplot as plt
from collections import OrderedDict, Counter
import json
from make_2by2_table_modules import Noverlap_hot_cold_dict_maker
import numpy as np
import copy
import sys
import random
from tqdm import tqdm
from scipy import stats

from make_auged_train_data_vs_ChIP_modules import peak_seq_maker, seq_maker, make_original_hot_data
from get_optimal_threshold import main as got_main


def get_information_at_each_position(chr_index,CNN_threshold):
    ret_od = OrderedDict()
    hot_cold_judged_fname = './peak_judgement_out/judged_chr_'+chr_index+'.json'
    tsv_fname = './Noverlap_predictions_bed/CNN_prediction_Noverlap_3aug_chr_'+chr_index+'.bed'
    current_chr_od_sorted_by_position = Noverlap_hot_cold_dict_maker(tsv_fname,hot_cold_judged_fname,chr_index)

    for key, value in current_chr_od_sorted_by_position.items():
        chr_info=key[0]
        pos_info=int(key[1])
        ChIP_which_info=key[2]
        prediction_score = value
        CNN_which = 0
        assert chr_info.lstrip('chr')==chr_index
        if CNN_threshold < prediction_score:
            CNN_which=1
        ret_od[(chr_info,pos_info)]=[ChIP_which_info,CNN_which]
        
    return ret_od


def devide_fragments(info_od):
    CNN_pos_ChIP_neg_center_positions = []
    CNN_neg_ChIP_neg_center_positions = []

    for key, value in info_od.items():
        chr_index = key[0].lstrip('chr')
        if chr_index == 'X':
            chr_index =23
        else:
            chr_index = int(chr_index)
        position = int(key[1])
        ChIP_which_info = value[0]
        CNN_which_info = value[1]

        if ChIP_which_info == 'hot':
            #ChIP_positions.append(position)
            continue
        else:
            if CNN_which_info==1:
                CNN_pos_ChIP_neg_center_positions.append(position)
            else:
                CNN_neg_ChIP_neg_center_positions.append(position)
    
    #return [CNN_pos_ChIP_neg_center_positions, CNN_neg_ChIP_neg_center_positions, ChIP_positions]
    return [CNN_pos_ChIP_neg_center_positions, CNN_neg_ChIP_neg_center_positions]


def getNearestValue(list, num):
    """
    概要: リストからある値に最も近い値を返却する関数
    @param list: データ配列
    @param num: 対象値
    @return 対象値に最も近い値
    """
    # リスト要素と対象値の差分を計算し最小値のインデックスを取得
    idx = np.abs(np.asarray(list) - num).argmin()
    return list[idx]


def plot_histgram(CNN_positive_distance_list, CNN_negative_distance_list):
    fig = plt.figure()
    ax = fig.add_subplot(1,1,1)
    bins = np.logspace(0,10, num=50)

    # ax.set_title('Distance to the nearest ChIP-seq peak center')
    # reference: https://qiita.com/ShoheiKojima/items/fa5128c14c8365a7b89c
    neg_n, neg_bins, _ = ax.hist(x=CNN_negative_distance_list,alpha=0.3,label='CNN-negative',bins=bins)
    pos_n, pos_bins, _ = ax.hist(x=CNN_positive_distance_list,alpha=0.3,label='CNN-positive',bins=bins)
    plt.xlabel('Distance(bp)')
    plt.ylabel('Frequency')
    plt.xlim(10**2, 10**6.5)
    print(stats.mannwhitneyu(CNN_negative_distance_list, CNN_positive_distance_list, alternative='two-sided'))
    plt.xscale("log")
    plt.legend()
    #plt.show()
    plt.savefig('random_sampled_100bp_CNN-positive_distance_histgram.png')
    
    od = OrderedDict()
    od['neg_n'] = neg_n.tolist()
    od['pos_n'] = pos_n.tolist()
    od['neg_bins'] = neg_bins.tolist()
    od['pos_bins'] = pos_bins.tolist()
    with open('CNN_hist.json', 'w') as f:
        json.dump(od,f)

    return [pos_n, neg_n]


def make_start_to_the_center(start_position, region_len):
    center = start_position + int(region_len/2)
    return center


def return_start_of_ChIP_region(chr_index):
    chr_index = str(chr_index)
    peak_fragments = peak_seq_maker(file_name='./100bp_seqs/GSE99407_ChIPseq_Peaks.YFP_HumanPRDM9.antiGFP.protocolN.p10e-5.sep250.Annotated.txt.gz',\
                                    chr_index=chr_index)
    seq = seq_maker(chr_index=chr_index, PATH='../make_Noverlap_fragments/hg19/')
    ChIP_peak_dict = make_original_hot_data(peak_fragments, seq)
    ret_list = sorted([key for key in ChIP_peak_dict.keys()])
    return ret_list


def main(chr_index, CNN_optimal_threshold, CNN_pos_distances, CNN_neg_distances):
    info_od = get_information_at_each_position(chr_index=chr_index,CNN_threshold=CNN_optimal_threshold)
    CNN_pos_ChIP_neg_start_positions, CNN_neg_ChIP_start_positions = devide_fragments(info_od)
    ChIP_region_start_positions = return_start_of_ChIP_region(chr_index)
    CNN_pos_ChIP_neg_center_positions, CNN_neg_ChIP_neg_center_positions, ChIP_region_center_positions = \
    [make_start_to_the_center(start,100)-1 for start in CNN_pos_ChIP_neg_start_positions], \
    [make_start_to_the_center(start,100)-1 for start in CNN_neg_ChIP_start_positions], \
    [make_start_to_the_center(start,301) for start in ChIP_region_start_positions]
    #print(CNN_pos_ChIP_neg_center_positions)

    sample_size = len(CNN_pos_ChIP_neg_center_positions)//10
    assert sample_size > 10
    assert sample_size<len(CNN_pos_ChIP_neg_center_positions) and sample_size<len(CNN_neg_ChIP_neg_center_positions)
    random_CNN_pos_positions = random.sample(CNN_pos_ChIP_neg_center_positions,sample_size)
    random_CNN_neg_positions = random.sample(CNN_neg_ChIP_neg_center_positions,sample_size)

    for random_CNN_pos_position, random_CNN_neg_position in zip(random_CNN_pos_positions,random_CNN_neg_positions):
        CNN_pos_nearest = getNearestValue(list=ChIP_region_center_positions,num=random_CNN_pos_position)
        CNN_pos_distances.append(abs(CNN_pos_nearest-random_CNN_pos_position))
        CNN_neg_nearest = getNearestValue(list=ChIP_region_center_positions,num=random_CNN_neg_position)
        CNN_neg_distances.append(abs(CNN_neg_nearest-random_CNN_neg_position))

    pos_n, neg_n = plot_histgram(CNN_positive_distance_list=CNN_pos_distances, CNN_negative_distance_list=CNN_neg_distances)
    #print('pos_n at chr{0}: '.format(chr_index), pos_n)
    #print('neg_n at chr{0}: '.format(chr_index),neg_n)
    return [CNN_pos_distances, CNN_neg_distances, len(CNN_pos_ChIP_neg_center_positions)]


if __name__=='__main__':
    # Use only autosome. 
    chr_indices = [str(i) for i in range(1,23)]
    CNN_pos_distances = []
    CNN_neg_distances = []
    CNN_positive_total = 0
    CNN_optimal_threshold, fpr_at_ot, tpr_at_ot= got_main('AUROC_100bp_3aug.json')
    print('fpr: ',fpr_at_ot)
    print('tpr: ',tpr_at_ot)
    for chr_index in tqdm(chr_indices):
        CNN_pos_distances, CNN_neg_distances, len_CNN_pos_ChIP_neg_center_positions = \
            main(chr_index=chr_index, \
                 CNN_optimal_threshold=CNN_optimal_threshold, \
                 CNN_pos_distances=CNN_pos_distances, \
                 CNN_neg_distances=CNN_neg_distances)
        CNN_positive_total += len_CNN_pos_ChIP_neg_center_positions

        print('# of total CNN_positive', CNN_positive_total)
    
    CNN_distance_dict = {}
    CNN_distance_dict['CNN_pos_distance'] = CNN_pos_distances
    CNN_distance_dict['CNN_neg_distance'] = CNN_neg_distances

    with open('CNN_distance_dict.json', 'w') as f:
        json.dump(CNN_distance_dict, f)
