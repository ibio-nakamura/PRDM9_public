import json
import numpy as np
import math


def main(fname):
    j_open = open(fname)
    j_dict = json.load(j_open)
    tpr = j_dict['tpr']
    fpr = j_dict['fpr']
    thr = j_dict['thresholds']

    ideal_point = np.array([0,1])
    ROC_points = [np.array([i,j]) for i,j in zip(fpr,tpr)]
    #print(ROC_points)
    assert len(thr)==len(ROC_points)

    distance = 1
    for i in range(len(thr)):
        current_point = ROC_points[i]
        current_difference = current_point - ideal_point
        current_distance = np.linalg.norm(current_difference)
        #print(current_distance)

        if current_distance < distance:
            distance = current_distance
            thr_opt = thr[i]
            fpr_opt, tpr_opt = current_point

    return thr_opt, fpr_opt, tpr_opt


if __name__ == '__main__':
    #print('PWM')
    #print(main('AUROC_PWM_vs_ChIP_global_sum.json'))
    print('CNN')
    print(main('AUROC_100bp_3aug.json'))
