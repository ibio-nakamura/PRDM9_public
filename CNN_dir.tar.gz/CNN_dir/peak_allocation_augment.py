import pandas as pd
import random
from Bio import SeqIO 
from tqdm import tqdm
import sys
"""
usage: python peak_allocation_augment.py [augtimes]
"""



def seq_list_maker(file_name='GSE99407_ChIPseq_Peaks.YFP_HumanPRDM9.antiGFP.protocolN.p10e-5.sep250.Annotated.txt.gz'):
    df = pd.read_csv(file_name, sep='\t')
    df_seq = df['sequence']

    seq_list = []
    for seq in df_seq:
        seq_list.append(seq)

    return seq_list


def seq_maker():
    file_name = "seq_chr1.fasta"
    with open(file_name, "r") as f:
        lines_list = f.readlines()
        newlines_removed_lines = [line.rstrip("\n") for line in lines_list]
        seq = ''.join(newlines_removed_lines)
        seq.lstrip(">NC_000001.10 Homo sapiens chromosome 1, GRCh37.p13 Primary Assembly")
    
    return seq

'''
def seq_maker_all():
    seq = ""
    for i in [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,"X"]:
        if type(i) == int:
            file_name = "seq_chr"+str(i+1)+".fasta"
        else:
            file_name = "seq_chr"+i+".fasta"
        with open(file_name, "r") as f:
            lines_list = f.readlines()
            lines_list.pop(0)
            new_lines_removed_lines = [line.rstrip("\n") for line in lines_list]
            print(new_lines_removed_lines)
            seq = seq.join(newlines_removed_lines)
            #list = [">NC_000001.10 Homo sapiens chromosome 1, GRCh37.p13 Primary Assembly", ">NC_000002.11 Homo sapiens chromosome 2, GRCh37.p13 Primary Assembly",">NC_000003.11 Homo sapiens chromosome 3, GRCh37.p13 Primary Assembly",">NC_000004.11 Homo sapiens chromosome 4, GRCh37.p13 Primary Assembly", ">NC_000005.9 Homo sapiens chromosome 5, GRCh37.p13 Primary Assembly",">NC_000006.11 Homo sapiens chromosome 6, GRCh37.p13 Primary Assembly",">NC_000007.13 Homo sapiens chromosome 7, GRCh37.p13 Primary Assembly",">NC_000008.10 Homo sapiens chromosome 8, GRCh37.p13 Primary Assembly",">NC_000009.11 Homo sapiens chromosome 9, GRCh37.p13 Primary Assembly",">NC_000010.10 Homo sapiens chromosome 10, GRCh37.p13 Primary Assembly",">NC_000011.9 Homo sapiens chromosome 11, GRCh37.p13 Primary Assembly",">NC_000012.11 Homo sapiens chromosome 12, GRCh37.p13 Primary Assembly",">NC_000013.10 Homo sapiens chromosome 13, GRCh37.p13 Primary Assembly",">NC_000014.8 Homo sapiens chromosome 14, GRCh37.p13 Primary Assembly",">NC_000015.9 Homo sapiens chromosome 15, GRCh37.p13 Primary Assembly",">NC_000016.9 Homo sapiens chromosome 16, GRCh37.p13 Primary Assembly",">NC_000017.10 Homo sapiens chromosome 17, GRCh37.p13 Primary Assembly",">NC_000018.9 Homo sapiens chromosome 18, GRCh37.p13 Primary Assembly",">NC_000019.9 Homo sapiens chromosome 19, GRCh37.p13 Primary Assembly",">NC_000020.10 Homo sapiens chromosome 20, GRCh37.p13 Primary Assembly",">NC_000021.8 Homo sapiens chromosome 21, GRCh37.p13 Primary Assembly",">NC_000022.10 Homo sapiens chromosome 22, GRCh37.p13 Primary Assembly"]
            #seq[0].lstrip(list[i])

    return seq
'''


def seq_maker_bio_all():
    seq = ""
    for i in [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,"X"]:
        if type(i)==int:
            print("第"+str(i+1)+"染色体ファイルをパース")
            file_name = "seq_chr"+str(i+1)+".fasta"
            with open(file_name, "r") as f:
                for seq_record in SeqIO.parse(f, "fasta"):
                    seq += seq_record.seq
        else:
            print(i+"染色体ファイルをパース")
            file_name = "seq_chr"+i+".fasta"
            with open(file_name, "r") as f:
                for seq_record in SeqIO.parse(f, "fasta"):
                    seq += seq_record.seq
    
    return seq


def correct_data_pos_detect(seq, correct_data_list):
    correct_data_pos_list = []
    times = 0

    for i, correct_data in tqdm(enumerate(correct_data_list)):
        pos = seq.find(correct_data.upper())

        if pos >= 1000000:
            times += 1
            seq = seq[1000000:]
            if times == 1:
                #print("a", pos)
                correct_data_pos_list.append(pos)
            else:
                pos += (times-1)*1000000
                #print("b", pos)
                correct_data_pos_list.append(pos)
        else:
            pos += times*1000000
            #print("c", pos)
            correct_data_pos_list.append(pos)

    
    return correct_data_pos_list


def make_uncorrect_data(correct_data_pos_list, seq):
    #input_length = 300
    uncorrect_data_list = []
    #i = 0
    #actual_pos = 0
    original_seq = seq

    for i, correct_data_pos in tqdm(enumerate(correct_data_pos_list)):
        if i < 160000:
            current_pos = correct_data_pos_list[i]
            next_pos = correct_data_pos_list[i+1]

            range_start = current_pos + 301
            range_end = next_pos - 300
            range = range_end - range_start

            if range > 300:
                random_start_pos = random.randrange(range_start, range_end)
                uncorrect_data = original_seq[random_start_pos:random_start_pos+301]
                if not("N" in uncorrect_data):
                    uncorrect_data_list.append(uncorrect_data)
        
    return uncorrect_data_list


# ピーク中心を移動させることができる.
def peak_allocation(seq, data_pos):
    while True:
        original_center = ((data_pos)+(data_pos+300))/2
        center_left = original_center - 15
        center_right = original_center + 15
        max_start = center_left
        min_start = center_right - 300
        new_start = random.randrange(min_start, max_start)
        allocated_peak_seq = seq[new_start:new_start+301]
        if not("N" in allocated_peak_seq):
            break


    return allocated_peak_seq


#今度は入れたデータに対して複数の配列を返す。
def peak_allocation_augmentation(seq, data_pos_list, aug_times):
    ret_seqs = []

    for data_pos in tqdm(data_pos_list):
        for i in range(int(aug_times)):
            allocated_seq = peak_allocation(seq, data_pos)
            ret_seqs.append(allocated_seq)
    
    return ret_seqs


if __name__ == "__main__":
    # デフォはaug_times = 1
    aug_times = 1
    args = sys.argv
    aug_times = args[1]

    correct_seq_list = seq_list_maker()
    seq = seq_maker_bio_all()
    correct_data_pos_list = correct_data_pos_detect(seq,correct_data_list=correct_seq_list)
    print("correct_seq_list: ", len(correct_seq_list))
    
    assert len(correct_data_pos_list) ==  len(correct_seq_list)
    allocated_auged_seqs = peak_allocation_augmentation(seq, correct_data_pos_list, aug_times)

    with open("hotspots_all_allo_aug_"+str(aug_times)+".fasta", "w") as f:
        for i, correct_seq in enumerate(allocated_auged_seqs):
            f.write("> hotseq"+str(i)+"\n")
            f.write((str(correct_seq).upper()+"\n"))
