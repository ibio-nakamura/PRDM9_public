import json
from collections import Counter
from tqdm import tqdm
import pandas as pd
from scipy import stats


def build_kmers(sequence, ksize):
    kmers = []                             # [] range of the variable
    n_kmers = len(sequence) - ksize + 1
    for i in range(n_kmers):
        kmer = sequence[i:i + ksize]
        kmers.append(kmer)
    return kmers

#if __name__ == '__main__':
#    print(build_kmers(sequence='ATGCCC',ksize=1))


def cross_test(CounterA, CounterB):
    A_AT = (CounterA['A']+CounterA['T'])
    A_GC = (CounterA['G']+CounterA['C'])
    B_AT = (CounterB['A']+CounterB['T'])
    B_GC = (CounterB['G']+CounterB['C'])
    df_cross = pd.DataFrame(
        [[A_AT,A_GC],[B_AT,B_GC]],
        index=['A','B'],
        columns=['AT','GC']
    )
    print(df_cross)
    print(stats.chi2_contingency(df_cross, correction=False))
    return 0


CNN_mistook_od = json.load(open('only_CNN_sequence.json'))
false_negative_seqs = CNN_mistook_od['false_negative']
false_positive_seqs = CNN_mistook_od['false_positive']
fp_kmers = []
fn_kmers = []
for seq in tqdm(false_positive_seqs):
    fp_kmers += build_kmers(sequence=seq,ksize=1)
for seq in tqdm(false_negative_seqs):
    fn_kmers += build_kmers(sequence=seq,ksize=1)

CNN_false_positive_kmers = Counter(fp_kmers)
CNN_false_negative_kmers = Counter(fn_kmers)
print('only_CNN_fp: ',CNN_false_positive_kmers)
print('only_CNN_fn: ',CNN_false_negative_kmers)

CNN_confusion_od = json.load(open('CNN_confusion_matrix_sequence.json'))
true_positive_seqs = CNN_confusion_od['true_positive']
false_negative_seqs = CNN_confusion_od['false_negative']
true_negative_seqs = CNN_confusion_od['true_negative']
false_positive_seqs = CNN_confusion_od['false_positive']
ground_positive_kmers = []
ground_negative_kmers = []
tp = []
fn = []
tn = []
fp = []
gp = []
gn = []
for seq in tqdm(true_positive_seqs):
    tp += build_kmers(sequence=seq,ksize=1)
for seq in tqdm(false_negative_seqs):
    fn += build_kmers(sequence=seq,ksize=1)
for seq in tqdm(true_negative_seqs):
    tn += build_kmers(sequence=seq,ksize=1)
for seq in tqdm(false_positive_seqs):
    fp += build_kmers(sequence=seq,ksize=1)
# checked.
for seq in tqdm(true_positive_seqs+false_negative_seqs):
    gp += build_kmers(sequence=seq,ksize=1)
for seq in tqdm(true_negative_seqs+false_positive_seqs):
    gn += build_kmers(sequence=seq,ksize=1)

tp_kmers = Counter(tp)
fn_kmers = Counter(fn)
tn_kmers = Counter(tn)
fp_kmers = Counter(fp)
gp_kmers = Counter(gp)
gn_kmers = Counter(gn)
print('CNN_tp: ',tp_kmers)
print('CNN_fn: ',fn_kmers)
print('CNN_tn: ',tn_kmers)
print('CNN_fp: ',fp_kmers)
print('ground positive: ', gp_kmers)
print('ground negative: ', gn_kmers)

# belows are for PWM
PWM_mistook_od = json.load(open('only_PWM_sequence.json'))
false_negative_seqs = PWM_mistook_od['false_negative']
false_positive_seqs = PWM_mistook_od['false_positive']
fp_kmers = []
fn_kmers = []
for seq in tqdm(false_positive_seqs):
    fp_kmers += build_kmers(sequence=seq,ksize=1)
for seq in tqdm(false_negative_seqs):
    fn_kmers += build_kmers(sequence=seq,ksize=1)

PWM_false_positive_kmers = Counter(fp_kmers)
PWM_false_negative_kmers = Counter(fn_kmers)
print('only_PWM_fp: ',PWM_false_positive_kmers)
print('only_PWM_fn: ',PWM_false_negative_kmers)

PWM_confusion_od = json.load(open('PWM_confusion_matrix_sequence.json'))
true_positive_seqs = PWM_confusion_od['true_positive']
false_negative_seqs = PWM_confusion_od['false_negative']
true_negative_seqs = PWM_confusion_od['true_negative']
false_positive_seqs = PWM_confusion_od['false_positive']
tp = []
fn = []
tn = []
fp = []
for seq in tqdm(true_positive_seqs):
    tp += build_kmers(sequence=seq,ksize=1)
for seq in tqdm(false_negative_seqs):
    fn += build_kmers(sequence=seq,ksize=1)
for seq in tqdm(true_negative_seqs):
    tn += build_kmers(sequence=seq,ksize=1)
for seq in tqdm(false_positive_seqs):
    fp += build_kmers(sequence=seq,ksize=1)
tp_kmers = Counter(tp)
fn_kmers = Counter(fn)
tn_kmers = Counter(tn)
fp_kmers = Counter(fp)
print('PWM_tp: ',tp_kmers)
print('PWM_fn: ',fn_kmers)
print('PWM_tn: ',tn_kmers)
print('PWM_fp: ',fp_kmers)


print('ground positive vs. ground negative')
cross_test(CounterA=gp_kmers, CounterB=gn_kmers)

print('only_CNN_fp vs. ground positive')
cross_test(CounterA=CNN_false_positive_kmers,CounterB=gp_kmers)

print('only_CNN_fn vs. ground negative')
cross_test(CounterA=CNN_false_negative_kmers,CounterB=gn_kmers)
