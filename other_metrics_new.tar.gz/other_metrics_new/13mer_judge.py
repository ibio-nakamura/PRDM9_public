import re
import json
from statsmodels.stats.proportion import proportions_ztest
from scipy import stats
import pandas as pd


def canonical_motif_judge(seq):
    match = re.search('CC.CC.T..CC.C',seq)
    rc_match = re.search('G.GG..A.GG.GG',seq)
    if match:
        return 1
    else:
        if rc_match:
            return 1
        else:
            return 0


def cross_test(A_1,A_2,B_1,B_2):
    df_cross = pd.DataFrame(
        [[A_1,A_2],[B_1,B_2]],
        index=['A','B'],
        columns=['occurence','total']
    )
    print(df_cross)
    print(stats.chi2_contingency(df_cross, correction=False))
    return 0


if __name__ == '__main__':
    only_CNN_seq_od = json.load(open('only_CNN_sequence.json'))
    only_CNN_false_positive_seqs = only_CNN_seq_od['false_positive']
    only_CNN_false_negative_seqs = only_CNN_seq_od['false_negative']
    only_CNN_true_positive_seqs = only_CNN_seq_od['true_positive']
    only_CNN_true_negative_seqs = only_CNN_seq_od['true_negative']
    only_CNN_fp_binary_list = []
    only_CNN_fn_binary_list = []
    only_CNN_tp_binary_list = []
    only_CNN_tn_binary_list = []
    for seq in only_CNN_false_positive_seqs:
        only_CNN_fp_binary_list.append(canonical_motif_judge(seq=seq))
    for seq in only_CNN_false_negative_seqs:
        only_CNN_fn_binary_list.append(canonical_motif_judge(seq=seq))
    for seq in only_CNN_true_positive_seqs:
        only_CNN_tp_binary_list.append(canonical_motif_judge(seq=seq))
    for seq in only_CNN_true_negative_seqs:
        only_CNN_tn_binary_list.append(canonical_motif_judge(seq=seq))
    print('# of only_CNN_false_positives which has 13-mer: {0}/{1}'.format(sum(only_CNN_fp_binary_list),len(only_CNN_false_positive_seqs)))
    print('# of only_CNN_false_negative which has 13-mer: {0}/{1}'.format(sum(only_CNN_fn_binary_list),len(only_CNN_false_negative_seqs)))
    print('# of only_CNN_true_positives which has 13-mer: {0}/{1}'.format(sum(only_CNN_tp_binary_list),len(only_CNN_true_positive_seqs)))
    print('# of only_CNN_true_negative which has 13-mer: {0}/{1}'.format(sum(only_CNN_tn_binary_list),len(only_CNN_true_negative_seqs)))
    
    all_seq_od = json.load(open('CNN_confusion_matrix_sequence.json'))
    tp_seqs = all_seq_od['true_positive']
    tn_seqs = all_seq_od['true_negative']
    fn_seqs = all_seq_od['false_negative']
    fp_seqs = all_seq_od['false_positive']
    tp_binary_list = []
    tn_binary_list = []
    fn_binary_list = []
    fp_binary_list = []
    for tp_seq in tp_seqs:
        tp_binary_list.append(canonical_motif_judge(seq=tp_seq))
    for tn_seq in tn_seqs:    
        tn_binary_list.append(canonical_motif_judge(seq=tn_seq))
    for fn_seq in fn_seqs:
        fn_binary_list.append(canonical_motif_judge(seq=fn_seq))
    for fp_seq in fp_seqs:
        fp_binary_list.append(canonical_motif_judge(seq=fp_seq))
    
    print('# of true positive(CNN): {0}/{1} '.format(sum(tp_binary_list),len(tp_seqs)))
    print('# of true negative(CNN): {0}/{1} '.format(sum(tn_binary_list),len(tn_seqs)))
    print('# of false negative(CNN): {0}/{1} '.format(sum(fn_binary_list),len(fn_seqs)))
    print('# of false positive(CNN): {0}/{1} '.format(sum(fp_binary_list),len(fp_seqs)))


    only_PWM_seq_od = json.load(open('only_PWM_sequence.json'))
    only_PWM_false_positive_seqs = only_PWM_seq_od['false_positive']
    only_PWM_false_negative_seqs = only_PWM_seq_od['false_negative']
    only_PWM_true_positive_seqs = only_PWM_seq_od['true_positive']
    only_PWM_true_negative_seqs = only_PWM_seq_od['true_negative']
    only_PWM_fp_binary_list = []
    only_PWM_fn_binary_list = []
    only_PWM_tp_binary_list = []
    only_PWM_tn_binary_list = []
    for seq in only_PWM_false_positive_seqs:
        only_PWM_fp_binary_list.append(canonical_motif_judge(seq=seq))
    for seq in only_PWM_false_negative_seqs:
        only_PWM_fn_binary_list.append(canonical_motif_judge(seq=seq))
    for seq in only_PWM_true_positive_seqs:
        only_PWM_tp_binary_list.append(canonical_motif_judge(seq=seq))
    for seq in only_PWM_true_negative_seqs:
        only_PWM_tn_binary_list.append(canonical_motif_judge(seq=seq))
    
    print('# of only_PWM_false_positives which has 13-mer: {0}/{1}'.format(sum(only_PWM_fp_binary_list),len(only_PWM_false_positive_seqs)))
    print('# of only_PWM_false_negative which has 13-mer: {0}/{1}'.format(sum(only_PWM_fn_binary_list),len(only_PWM_false_negative_seqs)))
    print('# of only_PWM_true_positives which has 13-mer: {0}/{1}'.format(sum(only_PWM_tp_binary_list),len(only_PWM_true_positive_seqs)))
    print('# of only_PWM_true_negative which has 13-mer: {0}/{1}'.format(sum(only_PWM_tn_binary_list),len(only_PWM_true_negative_seqs)))
    
    all_seq_od = json.load(open('PWM_confusion_matrix_sequence.json'))
    tp_seqs = all_seq_od['true_positive']
    tn_seqs = all_seq_od['true_negative']
    fn_seqs = all_seq_od['false_negative']
    fp_seqs = all_seq_od['false_positive']
    tp_binary_list = []
    tn_binary_list = []
    fn_binary_list = []
    fp_binary_list = []
    for tp_seq in tp_seqs:
        tp_binary_list.append(canonical_motif_judge(seq=tp_seq))
    for tn_seq in tn_seqs:    
        tn_binary_list.append(canonical_motif_judge(seq=tn_seq))
    for fn_seq in fn_seqs:
        fn_binary_list.append(canonical_motif_judge(seq=fn_seq))
    for fp_seq in fp_seqs:
        fp_binary_list.append(canonical_motif_judge(seq=fp_seq))
    
    print('# of true positive(PWM): {0}/{1} '.format(sum(tp_binary_list),len(tp_seqs)))
    print('# of true negative(PWM): {0}/{1} '.format(sum(tn_binary_list),len(tn_seqs)))
    print('# of false negative(PWM): {0}/{1} '.format(sum(fn_binary_list),len(fn_seqs)))
    print('# of false positive(PWM): {0}/{1} '.format(sum(fp_binary_list),len(fp_seqs)))


# https://datawokagaku.com/z_test/
print('only_CNN_fp vs. only_PWM_fp')
A_1 = sum(only_CNN_fp_binary_list)
A_2 = len(only_CNN_false_positive_seqs)
B_1 = sum(only_PWM_fp_binary_list)
B_2 = len(only_PWM_false_positive_seqs)
cons = cross_test(A_1,A_2,B_1,B_2)
print(cons)

print('only_CNN_fn vs. only_PWM_fn')
A_1 = sum(only_CNN_fn_binary_list)
A_2 = len(only_CNN_false_negative_seqs)
B_1 = sum(only_PWM_fn_binary_list)
B_2 = len(only_PWM_false_negative_seqs)
cons = cross_test(A_1,A_2,B_1,B_2)
print(cons)
