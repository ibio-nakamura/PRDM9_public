import json
import sys
from os import closerange
from typing import Sequence
import pandas as pd
import gzip as gz
import numpy as np
from sklearn.metrics import confusion_matrix, accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, roc_curve
from sklearn import metrics
from collections import OrderedDict
from matplotlib import pyplot as plt


CNN_scores_for_pos = []
CNN_scores_for_neg = []
PWM_scores_for_pos = []
PWM_scores_for_neg = []
pos_seqs = []
neg_seqs = []
pos_annotation_list = []
neg_annotation_list = []
path_to_CNN_test_data_predicition = '../CNN_dir/test_data_predictions_bed/'
path_to_PWM_test_data_prediction = '../PWM_dir/global_comp_each_testdata_calc_at_26/out_jsons/'
path_to_seqs = '../CNN_dir/100bp_seqs/100bp_train_test_fastas_dir/'
chr_indices = [str(i) for i in range(1,23)]
chr_indices.append('X')


def return_CNN_scores_from_bed(chr_index,path):
    #bed_fname = "CNN_prediction_testdata_original_chr_{0}.bed".format(chr_index)
    bed_fname = "CNN_prediction_testdata_allocated_chr_{0}.bed".format(chr_index)
    #bed_fname = "CNN_prediction_testdata_3aug_chr_{0}.bed".format(chr_index)
    current_df = pd.read_csv(path+bed_fname,sep='\t')
    df_for_pos = current_df.query('seq.str.startswith("positive")',engine='python')
    df_for_neg = current_df.query('seq.str.startswith("negative")', engine='python')
    scores_for_pos = list(df_for_pos['mc_prediction_probability'])
    scores_for_neg = list(df_for_neg['mc_prediction_probability'])

    return [scores_for_pos,scores_for_neg]


def return_PWM_scores_from_json(chr_index,path):
    json_fname_for_pos = "positive_integrated_global_comp_chr{0}.json".format(chr_index)
    json_fname_for_neg = "negative_integrated_global_comp_chr{0}.json".format(chr_index)
    dict_for_pos = json.load(open(path+json_fname_for_pos))
    dict_for_neg = json.load(open(path+json_fname_for_neg))
    scores_for_pos = [score for score in dict_for_pos.values()]
    scores_for_neg = [score for score in dict_for_neg.values()]
    
    return [scores_for_pos,scores_for_neg]


def load_fasta_gz_and_return_seqs(chr_index,path,input_len):
    positive_sequences = []
    negative_sequences = []
    pos_annotation_list = []
    neg_annotation_list = []
    hot_fname = '100bp_positive_test_chr{0}.fasta.gz'.format(chr_index)
    cold_fname = '100bp_negative_test_chr{0}.fasta.gz'.format(chr_index)
    for fname in [hot_fname,cold_fname]:
        cur_string = ""
        s = 0
        with gz.open(path+fname) as fasta_file:
            for line in fasta_file:
                line = line.decode("ascii")
                if line[0] == '>':
                    if fname==hot_fname:
                        pos_annotation_list.append((chr_index,line.lstrip('>').rstrip('\n')))
                    elif fname==cold_fname:
                        neg_annotation_list.append((chr_index,line.lstrip('>').rstrip('\n')))
                    s+=1
                    if cur_string:
                        assert len(cur_string) ==input_len
                        if fname==hot_fname:
                            positive_sequences.append(cur_string)
                        elif fname==cold_fname:
                            negative_sequences.append(cur_string)
                    cur_string = ""
                else:
                    line = line.strip()
                    cur_string += line

            assert len(cur_string) ==input_len
            if fname==hot_fname:
                positive_sequences.append(cur_string)
            elif fname==cold_fname:
                negative_sequences.append(cur_string)
    
    assert len(positive_sequences)==len(pos_annotation_list)
    assert len(negative_sequences)==len(neg_annotation_list)

    return [positive_sequences,negative_sequences,pos_annotation_list,neg_annotation_list]


def get_optimal_threshold(ROC_json,path):
    j_open = open(path+ROC_json)
    j_dict = json.load(j_open)
    tpr = j_dict['tpr']
    fpr = j_dict['fpr']
    thr = j_dict['thresholds']
    ideal_point = np.array([0,1])
    ROC_points = [np.array([i,j]) for i,j in zip(fpr,tpr)]
    assert len(thr)==len(ROC_points)
    distance = 1
    for i in range(len(thr)):
        current_point = ROC_points[i]
        current_difference = current_point - ideal_point
        current_distance = np.linalg.norm(current_difference)
        if current_distance < distance:
            distance = current_distance
            thr_opt = thr[i]
            fpr_opt, tpr_opt = current_point

    return thr_opt, fpr_opt, tpr_opt


def return_specificity_from_confusion_matrix(confusion_matrix):
    tn, fp, fn, tp = confusion_matrix.flatten()
    #print(tn, fp, fn, tp)
    #accuracy = (tn+tp)/(fn+tn+fp+tp)
    #print(accuracy)
    specificity = tn/(fp+tn)
    return specificity


def return_metrics(y_true,y_preds):
    accuracy = accuracy_score(y_true,y_preds)
    precision = precision_score(y_true,y_preds)
    recall = recall_score(y_true,y_preds)
    f1score = f1_score(y_true,y_preds)
    cm = confusion_matrix(y_true,y_preds)
    return [accuracy,precision,recall,f1score,cm]


def detect_CNN_mistake(y_true,CNN_preds,PWM_preds,seqs,annotations):
    assert len(y_true)==len(CNN_preds)
    assert len(CNN_preds)==len(seqs)
    assert len(seqs)==len(annotations)
    assert len(annotations)==len(PWM_preds)


    false_negative_seqs = []
    false_negative_annotation = []
    false_positive_seqs = []
    false_positive_annotation = []
    for i, true_binary in enumerate(y_true):
        if PWM_preds[i]==true_binary and CNN_preds[i]!=true_binary:
            if true_binary==1:
                false_negative_seqs.append(seqs[i])
                false_negative_annotation.append(annotations[i])
            else:
                false_positive_seqs.append(seqs[i])
                false_positive_annotation.append(annotations[i])
                

    return [false_negative_seqs,false_positive_seqs,false_negative_annotation,false_positive_annotation]


def detect_PWM_mistake(y_true,CNN_preds,PWM_preds,seqs,annotations):
    assert len(y_true)==len(CNN_preds)
    assert len(CNN_preds)==len(seqs)
    assert len(seqs)==len(annotations)
    assert len(annotations)==len(PWM_preds)

    false_negative_seqs = []
    false_negative_annotation = []
    false_positive_seqs = []
    false_positive_annotation = []
    for i, true_binary in enumerate(y_true):
        if PWM_preds[i]!=true_binary and CNN_preds[i]==true_binary:
            if true_binary==1:
                false_negative_seqs.append(seqs[i])
                false_negative_annotation.append(annotations[i])
            else:
                false_positive_seqs.append(seqs[i])
                false_positive_annotation.append(annotations[i])

    return [false_negative_seqs,false_positive_seqs,false_negative_annotation,false_positive_annotation]


def detect_CNN_truth(y_true,CNN_preds,PWM_preds,seqs,annotations):
    assert len(y_true)==len(CNN_preds)
    assert len(CNN_preds)==len(seqs)
    assert len(seqs)==len(annotations)
    assert len(annotations)==len(PWM_preds)

    true_negative_seqs = []
    true_negative_annotation = []
    true_positive_seqs = []
    true_positive_annotation = []
    for i, true_binary in enumerate(y_true):
        if PWM_preds[i]!=true_binary and CNN_preds[i]==true_binary:
            if true_binary==1:
                true_positive_seqs.append(seqs[i])
                true_positive_annotation.append(annotations[i])
            else:
                true_negative_seqs.append(seqs[i])
                true_negative_annotation.append(annotations[i])

    return [true_negative_seqs,true_positive_seqs,true_negative_annotation,true_positive_annotation]


def detect_PWM_truth(y_true,CNN_preds,PWM_preds,seqs,annotations):
    assert len(y_true)==len(CNN_preds)
    assert len(CNN_preds)==len(seqs)
    assert len(seqs)==len(annotations)
    assert len(annotations)==len(PWM_preds)
    
    true_negative_seqs = []
    true_negative_annotation = []
    true_positive_seqs = []
    true_positive_annotation = []
    for i, true_binary in enumerate(y_true):
        if PWM_preds[i]==true_binary and CNN_preds[i]!=true_binary:
            if true_binary==1:
                true_positive_seqs.append(seqs[i])
                true_positive_annotation.append(annotations[i])
            else:
                true_negative_seqs.append(seqs[i])
                true_negative_annotation.append(annotations[i])

    return [true_negative_seqs,true_positive_seqs,true_negative_annotation,true_positive_annotation]


def detect_both(y_true,CNN_preds,PWM_preds,seqs,annotations):
    assert len(y_true)==len(CNN_preds)
    assert len(CNN_preds)==len(seqs)
    assert len(seqs)==len(annotations)
    assert len(annotations)==len(PWM_preds)

    both_true_positive_seqs = []
    both_false_negative_seqs = []
    both_true_negative_seqs = []
    both_false_positive_seqs = []
    for i, true_binary in enumerate(y_true):
        if PWM_preds[i]==true_binary and CNN_preds[i]==true_binary:
            if true_binary==1:
                both_true_positive_seqs.append(seqs[i])
            else:
                both_true_negative_seqs.append(seqs[i])
        elif PWM_preds[i]!=true_binary and CNN_preds[i]!=true_binary:
            if true_binary==1:
                both_false_negative_seqs.append(seqs[i])
            else:
                both_false_positive_seqs.append(seqs[i])

    return [both_true_positive_seqs,both_true_negative_seqs,both_false_negative_seqs,both_false_positive_seqs]


def return_confusion_matrix_with_seqs(y_true,preds,seqs):
    true_negative_seqs = []
    true_positive_seqs = []
    false_negative_seqs = []
    false_positive_seqs = []
    for i, true_binary in enumerate(y_true):
        if preds[i]==true_binary:
            if true_binary==1:
                true_positive_seqs.append(seqs[i])
            else:
                true_negative_seqs.append(seqs[i])
        else:
            if true_binary==1:
                false_negative_seqs.append(seqs[i])
            else:
                false_positive_seqs.append(seqs[i])

    return [true_positive_seqs,true_negative_seqs,false_negative_seqs,false_positive_seqs]


for chr_index in chr_indices:
    current_chr_CNN_scores_for_pos, current_chr_CNN_scores_for_neg = return_CNN_scores_from_bed(chr_index=chr_index,\
                                                                                                path=path_to_CNN_test_data_predicition)
    CNN_scores_for_pos += current_chr_CNN_scores_for_pos
    CNN_scores_for_neg += current_chr_CNN_scores_for_neg
    current_chr_PWM_scores_for_pos, current_chr_PWM_scores_for_neg = return_PWM_scores_from_json(chr_index=chr_index,\
                                                                                                 path=path_to_PWM_test_data_prediction)
    
    PWM_scores_for_pos += current_chr_PWM_scores_for_pos
    PWM_scores_for_neg += current_chr_PWM_scores_for_neg
    
    current_pos_seqs, current_neg_seqs, current_pos_annotation_list, current_neg_annotation_list \
                                                            = load_fasta_gz_and_return_seqs(chr_index=chr_index,\
                                                                                            path=path_to_seqs,\
                                                                                            input_len=100)
    # assert that the dict order is preserved.
    PWM_json_fname_for_pos = "positive_integrated_global_comp_chr{0}.json".format(chr_index)
    PWM_json_fname_for_neg = "negative_integrated_global_comp_chr{0}.json".format(chr_index)
    path = path_to_PWM_test_data_prediction
    PWM_dict_for_pos = json.load(open(path+PWM_json_fname_for_pos))
    PWM_dict_for_neg = json.load(open(path+PWM_json_fname_for_neg))
    for i, key in enumerate(current_pos_annotation_list):
        chr_index_, seq_key = key
        assert chr_index==chr_index_
        assert PWM_dict_for_pos[seq_key]==current_chr_PWM_scores_for_pos[i]
    for j, key in enumerate(current_neg_annotation_list):
        chr_index_, seq_key = key
        assert chr_index==chr_index_
        assert PWM_dict_for_neg[seq_key]==current_chr_PWM_scores_for_neg[j]
    
    pos_seqs += current_pos_seqs
    neg_seqs += current_neg_seqs
    pos_annotation_list += current_pos_annotation_list
    neg_annotation_list += current_neg_annotation_list


assert len(CNN_scores_for_pos)==len(PWM_scores_for_pos) and len(CNN_scores_for_neg)==len(PWM_scores_for_neg)
y_true = [1]*len(CNN_scores_for_pos)+[0]*len(CNN_scores_for_neg)


#CNN_optimal_thr,CNN_fpr_at_opt,CNN_tpr_at_opt = get_optimal_threshold(ROC_json='AUROC_100bp_3aug.json',\
#                                                                      path='../CNN_dir/')
CNN_optimal_thr,CNN_fpr_at_opt,CNN_tpr_at_opt = get_optimal_threshold(ROC_json='AUROC_100bp_allocated.json',\
                                                                      path='../CNN_dir/')
#CNN_optimal_thr,CNN_fpr_at_opt,CNN_tpr_at_opt = get_optimal_threshold(ROC_json='AUROC_100bp_original.json',\
#                                                                      path='../CNN_dir/')
PWM_optimal_thr,PWM_fpr_at_opt,PWM_tpr_at_opt = get_optimal_threshold(ROC_json='ROC_PWM_global_comp.json',\
                                                                      path='../PWM_dir/global_comp_each_testdata_calc_at_26/')
print('CNN_fpr_at_opt: ',CNN_fpr_at_opt)
print('CNN_tpr_at_opt: ',CNN_tpr_at_opt)
print('PWM_fpr_at_opt: ',PWM_fpr_at_opt)
print('PWM_tpr_at_opt: ',PWM_tpr_at_opt)

CNN_preds = [1 if CNN_optimal_thr<=score else 0 for score in CNN_scores_for_pos+CNN_scores_for_neg]
PWM_preds = [1 if PWM_optimal_thr<=score else 0 for score in PWM_scores_for_pos+PWM_scores_for_neg]
CNN_auc = roc_auc_score(y_true=y_true,y_score=CNN_scores_for_pos+CNN_scores_for_neg)
PWM_auc = roc_auc_score(y_true=y_true,y_score=PWM_scores_for_pos+PWM_scores_for_neg)
print('AUC of CNN: {0}'.format(CNN_auc))
print('AUC of PWM: {0}'.format(PWM_auc))
CNN_accuracy, CNN_precision, CNN_recall, CNN_f1_score, CNN_confusion_matrix = return_metrics(y_true=y_true,y_preds=CNN_preds)
PWM_accuracy, PWM_precision, PWM_recall, PWM_f1_score, PWM_confusion_matrix = return_metrics(y_true=y_true,y_preds=PWM_preds)
CNN_specificity = return_specificity_from_confusion_matrix(CNN_confusion_matrix)
PWM_specificity = return_specificity_from_confusion_matrix(PWM_confusion_matrix)
print('metric {0}, {1}'.format('CNN','PWM'))
print('accuracy {0}, {1}'.format(CNN_accuracy,PWM_accuracy))
print('recall(sensitivity) {0}, {1}'.format(CNN_recall,PWM_recall))
print('specificity {0}, {1}'.format(CNN_specificity,PWM_specificity))
print('false positive rate {0}, {1}'.format(1-CNN_specificity,1-PWM_specificity))
print('precision {0}, {1}'.format(CNN_precision,PWM_precision))
print('f1-score {0} {1}'.format(CNN_f1_score,PWM_f1_score))
print('confusion matrix\n {0},\n {1}'.format(CNN_confusion_matrix,PWM_confusion_matrix))
#sys.exit()

CNN_false_negative_seqs,CNN_false_positive_seqs, CNN_false_negative_annotations, CNN_false_positive_annotations \
                                                                        = detect_CNN_mistake(y_true=y_true,\
                                                                                             CNN_preds=CNN_preds,\
                                                                                             PWM_preds=PWM_preds,\
                                                                                             seqs=pos_seqs+neg_seqs,\
                                                                                             annotations=pos_annotation_list+neg_annotation_list)

CNN_true_negative_seqs,CNN_true_positive_seqs,CNN_true_negative_annotation,CNN_true_positive_annotation \
                                                                        = detect_CNN_truth(y_true=y_true,\
                                                                                           CNN_preds=CNN_preds,\
                                                                                           PWM_preds=PWM_preds,seqs=pos_seqs+neg_seqs,\
                                                                                           annotations=pos_annotation_list+neg_annotation_list)

both_true_positive_seqs,both_true_negative_seqs,both_false_negative_seqs,both_false_positive_seqs \
                                                                        = detect_both(y_true=y_true,\
                                                                                      CNN_preds=CNN_preds,\
                                                                                      PWM_preds=PWM_preds,seqs=pos_seqs+neg_seqs,\
                                                                                      annotations=pos_annotation_list+neg_annotation_list)
print('both-true-positive: {0}'.format(len(both_true_positive_seqs)))
print('both-true-negative: {0}'.format(len(both_true_negative_seqs)))
print('both-false-negative: {0}'.format(len(both_false_negative_seqs)))
print('both-false-positive: {0}'.format(len(both_false_positive_seqs)))

od = OrderedDict()
od['false_negative'] = CNN_false_negative_seqs
od['false_positive'] = CNN_false_positive_seqs
od['true_negative'] = CNN_true_negative_seqs
od['true_positive'] = CNN_true_positive_seqs
with open('only_CNN_sequence.json','w') as f:
    json.dump(od,f)

false_negative_annotations_od = OrderedDict()
false_positive_annotations_od = OrderedDict()
seq_annotations_list = [[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[]]
seq_annotations_dict = OrderedDict()
for annotation in CNN_false_negative_annotations:
    chr_index, seq_annotation = annotation
    if chr_index=='X':
        chr_index=23
    index = int(chr_index)-1
    current_list = seq_annotations_list[index]
    current_list.append(seq_annotation)
    seq_annotations_list[index] = current_list

for chr_index, seq_annotations in zip(chr_indices,seq_annotations_list):
    false_negative_annotations_od[chr_index] = seq_annotations
with open('only_CNN_false_negative.json','w') as f:
    json.dump(false_negative_annotations_od,f)

seq_annotations_list = [[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[]]
for annotation in CNN_false_positive_annotations:
    chr_index, seq_annotation = annotation
    if chr_index=='X':
        chr_index=23
    index = int(chr_index)-1
    current_list = seq_annotations_list[index]
    current_list.append(seq_annotation)
    seq_annotations_list[index] = current_list
for chr_index, seq_annotations in zip(chr_indices,seq_annotations_list):
    false_positive_annotations_od[chr_index] = seq_annotations
with open('only_CNN_false_positive.json','w') as f:
    json.dump(false_positive_annotations_od,f)


PWM_false_negative_seqs, PWM_false_positive_seqs, PWM_false_negative_annotations, PWM_false_positive_annotations \
                                                                        = detect_PWM_mistake(y_true=y_true,\
                                                                                             CNN_preds=CNN_preds,\
                                                                                             PWM_preds=PWM_preds,\
                                                                                             seqs=pos_seqs+neg_seqs,\
                                                                                             annotations=pos_annotation_list+neg_annotation_list)

PWM_true_negative_seqs, PWM_true_positive_seqs, PWM_true_negative_annotation, PWM_true_positive_annotation \
                                                                        = detect_PWM_truth(y_true=y_true,\
                                                                                           CNN_preds=CNN_preds,\
                                                                                           PWM_preds=PWM_preds,\
                                                                                           seqs=pos_seqs+neg_seqs,\
                                                                                           annotations=pos_annotation_list+neg_annotation_list)

od = OrderedDict()
od['false_negative'] = PWM_false_negative_seqs
od['false_positive'] = PWM_false_positive_seqs
od['true_negative'] = PWM_true_negative_seqs
od['true_positive'] = PWM_true_positive_seqs
with open('only_PWM_sequence.json','w') as f:
    json.dump(od,f)

false_negative_annotations_od = OrderedDict()
false_positive_annotations_od = OrderedDict()
seq_annotations_list = [[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[]]
seq_annotations_dict = OrderedDict()

for annotation in PWM_false_negative_annotations:
    chr_index, seq_annotation = annotation
    if chr_index=='X':
        chr_index=23
    index = int(chr_index)-1
    current_list = seq_annotations_list[index]
    current_list.append(seq_annotation)
    seq_annotations_list[index] = current_list

for chr_index, seq_annotations in zip(chr_indices,seq_annotations_list):
    false_negative_annotations_od[chr_index] = seq_annotations
with open('only_PWM_false_negative.json','w') as f:
    json.dump(false_negative_annotations_od,f)

seq_annotations_list = [[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[]]
for annotation in PWM_false_positive_annotations:
    chr_index, seq_annotation = annotation
    if chr_index=='X':
        chr_index=23
    index = int(chr_index)-1
    current_list = seq_annotations_list[index]
    current_list.append(seq_annotation)
    seq_annotations_list[index] = current_list
for chr_index, seq_annotations in zip(chr_indices,seq_annotations_list):
    false_positive_annotations_od[chr_index] = seq_annotations
with open('only_PWM_false_positive.json','w') as f:
    json.dump(false_positive_annotations_od,f)


# make a dictionary that has sequences for each category.
CNN_true_positive_seqs, CNN_true_negative_seqs, CNN_false_negative_seqs, CNN_false_positive_seqs \
                                                                    = return_confusion_matrix_with_seqs(y_true=y_true,\
                                                                                                        preds=CNN_preds,\
                                                                                                        seqs=pos_seqs+neg_seqs)
confusion_matrix_sequence_od = OrderedDict()
confusion_matrix_sequence_od['true_positive'] = CNN_true_positive_seqs
confusion_matrix_sequence_od['true_negative'] = CNN_true_negative_seqs
confusion_matrix_sequence_od['false_negative'] = CNN_false_negative_seqs
confusion_matrix_sequence_od['false_positive'] = CNN_false_positive_seqs
with open('CNN_confusion_matrix_sequence.json','w') as f:
    json.dump(confusion_matrix_sequence_od,f)

PWM_true_positive_seqs, PWM_true_negative_seqs, PWM_false_negative_seqs, PWM_false_positive_seqs \
                                                                    = return_confusion_matrix_with_seqs(y_true=y_true,\
                                                                                                        preds=PWM_preds,\
                                                                                                        seqs=pos_seqs+neg_seqs)
confusion_matrix_sequence_od = OrderedDict()
confusion_matrix_sequence_od['true_positive'] = PWM_true_positive_seqs
confusion_matrix_sequence_od['true_negative'] = PWM_true_negative_seqs
confusion_matrix_sequence_od['false_negative'] = PWM_false_negative_seqs
confusion_matrix_sequence_od['false_positive'] = PWM_false_positive_seqs
with open('PWM_confusion_matrix_sequence.json','w') as f:
    json.dump(confusion_matrix_sequence_od,f)
    