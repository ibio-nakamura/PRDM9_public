import json
import pandas as pd
from collections import OrderedDict
from tqdm import tqdm
import sys
import numpy as np

# calculates the recombination rate and makes a dictionary by dividing the units into 100 units each.
def map_parser(map_name):
    # The dictionary is in the format {pos where the unit begins: recombination rate between the pos and next 100 bp}.
    header = ["Chromosome", "Position(bp)", "Rate(cM/Mb)", "Map(cM)"]
    df = pd.read_csv(map_name, sep="\t", encoding='utf-8', header=0)
    df.columns = header[:len(df.columns)]
    pos_df = df["Position(bp)"]
    rate_df = df["Rate(cM/Mb)"]
    pos_list = list(pos_df)
    rate_list = list(rate_df)
    pos_rate_od = OrderedDict()

    for pos, rate in zip(pos_list, rate_list):
        pos_rate_od[pos] = rate

    return pos_rate_od


def Units(jsonfile_name):
    pos_list = []
    likelihood_open = open(jsonfile_name)
    likelihood_dict = json.load(likelihood_open)

    for i in range(len(likelihood_dict)):
        pos = 100*i
        likelihood = likelihood_dict["FragmentStartsFrom"+str(pos)]
        if likelihood == 1:
            continue
        else:
            pos_list.append((pos,pos+99))
    
    return pos_list


# Calculate the recombination rate when a 100bp unit enters the argument
def RecombinationInUnits(pos_rate_od, unit):
    unit_start = unit[0]
    unit_end = unit[1]

    # want to delete unit_backward_index and unit_forward_index every time the fragment area is entered in the for roop.
    if "unit_backward_index" in locals():
        locals().pop("unit_backward_index")
    if "unit_forward_index" in locals():
        locals().pop("unit_forward_index")

    #mapに記されたpos:組換え率のdictionary
    for i, pos in enumerate(pos_rate_od):
        #  # When the start position of the fragment unit is larger than the start position of the map, and unit_backward_index does not exist.
        if i>0 and (unit_start<=pos) and not "unit_backward_index" in locals():
            unit_backward_index = i-1
        # If the end position of the fragment unit is larger than the end position of the map, and unit_forward_index does not exist
        if i>0 and (unit_end<=pos) and not "unit_forward_index" in locals():
            unit_forward_index = i
            break
    
    if (not "unit_backward_index" in locals()) or (not "unit_forward_index" in locals()):
        print('None was returned at {0}'.format(unit_start))
        return None

    # The pos_rate_tupple_list contains cM/Mb of the unit.
    pos_rate_tupple_list = []
    for index in range(unit_backward_index, unit_forward_index+1):
        pos_rate_tupple_list.append(list(pos_rate_od.items())[index])
    len_pos_rate_tupple_list = len(pos_rate_tupple_list)
    whole_range = 0
    exps = []
    if len_pos_rate_tupple_list == 2:
        first_tupple = pos_rate_tupple_list[0]
        #next_tupple = pos_rate_tupple_list[1]
        rate = first_tupple[1]
        the_range = unit_end - unit_start + 1
        whole_range += the_range
        assert whole_range==100, "the range has {0} bp.".format(str(range))
        exp = (rate*the_range)/(10**6)
        exps.append(exp)

    
    elif len_pos_rate_tupple_list > 2:
        for i in range(len_pos_rate_tupple_list-1):
            if i == 0:
                first_tupple = pos_rate_tupple_list[i]
                next_tupple = pos_rate_tupple_list[i+1]
                rate = first_tupple[1]
                next_tupple_start = next_tupple[0]
                the_range = next_tupple_start - unit_start
                whole_range += the_range
                exp = (rate*the_range)/(10**6)
                exps.append(exp)
            elif i < len_pos_rate_tupple_list-2:
                current_tupple = pos_rate_tupple_list[i]
                next_tupple = pos_rate_tupple_list[i+1]
                rate = current_tupple[1]
                current_tupple_start = current_tupple[0]
                next_tupple_start = next_tupple[0]
                the_range = next_tupple_start - current_tupple_start
                whole_range += the_range
                exp = (rate*the_range)/(10**6)
                exps.append(exp)
            elif i == len_pos_rate_tupple_list-2:
                current_tupple = pos_rate_tupple_list[i]
                rate = current_tupple[1]
                current_tupple_start = current_tupple[0]
                the_range = unit_end - current_tupple_start + 1
                whole_range += the_range
                exp = (rate*the_range)/(10**6)
                exps.append(exp)
        assert whole_range==100, "the range has"+str(whole_range)+"bp."
    else:
        print('Something is wrong at {0}'.format(pos_rate_tupple_list[i]))
        sys.exit()


    ret = sum(exps)/100

    return ret
