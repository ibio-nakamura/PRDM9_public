#!/bin/bash

python calc_100bp_Noverlap_rec_rate_starts_from_0.py 1 > /dev/null &
python calc_100bp_Noverlap_rec_rate_starts_from_0.py 2 > /dev/null &
python calc_100bp_Noverlap_rec_rate_starts_from_0.py 3 > /dev/null &
python calc_100bp_Noverlap_rec_rate_starts_from_0.py 4 > /dev/null &
python calc_100bp_Noverlap_rec_rate_starts_from_0.py 5 > /dev/null &
python calc_100bp_Noverlap_rec_rate_starts_from_0.py 6 > /dev/null &
python calc_100bp_Noverlap_rec_rate_starts_from_0.py 7 > /dev/null &
python calc_100bp_Noverlap_rec_rate_starts_from_0.py 8 > /dev/null &
python calc_100bp_Noverlap_rec_rate_starts_from_0.py 9 > /dev/null &
python calc_100bp_Noverlap_rec_rate_starts_from_0.py 10 > /dev/null &
