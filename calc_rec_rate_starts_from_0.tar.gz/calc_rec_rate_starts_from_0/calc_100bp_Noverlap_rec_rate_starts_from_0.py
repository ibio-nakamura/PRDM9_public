import pandas as p1
import random
from Bio import SeqIO 
from tqdm import tqdm
from make_new_recombination_in_unit_for_100bp import map_parser, RecombinationInUnits
import json
from data_utils import load_fasta_gz_and_return_OrderedDict
from collections import OrderedDict
import sys


def main(chr_index):
    Noverlap_fname = "./100bp_Noverlap_fastas/100bp_NoverlapChr{0}.fasta.gz".format(chr_index)
    pos_seq_od = load_fasta_gz_and_return_OrderedDict(f_name=Noverlap_fname,input_len=100)
    unit_start_indices = [int((((key.strip()).replace('<unknown description>','')).replace('Chr'+chr_index+'FragmentStartsFrom',''))) for key in pos_seq_od]

    pos_rate_dict = map_parser(map_name='./CEU/CEU_recombination_map_hapmap_format_hg19_chr_'+str(chr_index)+'.txt')
    map_pos_list = [int(pos) for pos in pos_rate_dict]
    map_start = min(map_pos_list)
    map_end = max(map_pos_list)
    units = [(start_index,start_index+99) for start_index in unit_start_indices]

    rec_rate_dict={}
    print("Now making a dictionary of recombination rate corresponding to position.")
    for unit in tqdm(units):
        unit_start = unit[0]
        if (map_start<=unit_start) and (unit_start<=map_end-99):
            rec_rate_dict[unit_start] = RecombinationInUnits(pos_rate_dict, unit)

    # calculate average rec. rate.
    rec_sum = sum(rec_rate_dict.values())
    mean_rec_rate = rec_sum/len(rec_rate_dict)
    print("rec_rate:", mean_rec_rate)
    print("N_samples:", len(rec_rate_dict))

    with open("./rec_rate_100bp_starts_from_0/rec_rate_100bp_chr{0}.json".format(chr_index),"w") as f:
        json.dump(rec_rate_dict,f,indent=4)


if __name__ == "__main__":
        
    chr_index = str(sys.argv[1])
    main(chr_index)
