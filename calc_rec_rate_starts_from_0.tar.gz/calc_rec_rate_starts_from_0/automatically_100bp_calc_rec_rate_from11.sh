#!/bin/bash

python calc_100bp_Noverlap_rec_rate_starts_from_0.py X > /dev/null &
python calc_100bp_Noverlap_rec_rate_starts_from_0.py 11 > /dev/null &
python calc_100bp_Noverlap_rec_rate_starts_from_0.py 12 > /dev/null &
python calc_100bp_Noverlap_rec_rate_starts_from_0.py 13 > /dev/null &
python calc_100bp_Noverlap_rec_rate_starts_from_0.py 14 > /dev/null &
python calc_100bp_Noverlap_rec_rate_starts_from_0.py 15 > /dev/null &
python calc_100bp_Noverlap_rec_rate_starts_from_0.py 16 > /dev/null &
python calc_100bp_Noverlap_rec_rate_starts_from_0.py 17 > /dev/null &
python calc_100bp_Noverlap_rec_rate_starts_from_0.py 18 > /dev/null &
python calc_100bp_Noverlap_rec_rate_starts_from_0.py 19 > /dev/null &
python calc_100bp_Noverlap_rec_rate_starts_from_0.py 20 > /dev/null &
python calc_100bp_Noverlap_rec_rate_starts_from_0.py 21 > /dev/null &
python calc_100bp_Noverlap_rec_rate_starts_from_0.py 22 > /dev/null &
