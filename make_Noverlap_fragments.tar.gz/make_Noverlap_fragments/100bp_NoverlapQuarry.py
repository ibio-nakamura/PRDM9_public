from Bio import SeqIO
from Bio.SeqRecord import SeqRecord
from Bio.Seq import Seq
from tqdm import tqdm

def make_one_sequence_from_fasta(Chr_fasta_file):
    for record in SeqIO.parse(Chr_fasta_file, "fasta"):
        seq = record.seq

    return seq


def main(Chr_fasta_file,chr_index,input_len):
    seq = make_one_sequence_from_fasta(Chr_fasta_file)    
    iter = len(seq)//input_len
    iter_residue = len(seq)%input_len
    fragments = []
    
    print("Now making Noverlap fasta file of chr"+chr_index+".")
    for i in tqdm(range(iter)):
        start_pos = input_len*i
        rec = SeqRecord(Seq(str(seq[start_pos:start_pos+input_len]).upper()), id="Chr"+chr_index+"FragmentStartsFrom"+str(start_pos))
        fragments.append(rec)
    
    assert len(seq)==len(fragments)*input_len+iter_residue, "total fragments length doesn't match with sequence length."
    assert (len(seq)-input_len*iter) < input_len
    SeqIO.write(fragments, "./100bp_Noverlap_fastas/100bp_NoverlapChr"+str(chr_index)+".fasta", "fasta")


if __name__ == "__main__":
    chr_index_list = [str(1),str(2),str(3),str(4),str(5),str(6),str(7),str(8),str(9),str(10),str(11),str(12),str(13),str(14),str(15),str(16),str(17),str(18),str(19),str(20),str(21),str(22),"X"]
    for chr_index in chr_index_list:
        main(Chr_fasta_file="./hg19/chr"+chr_index+".fa",chr_index=chr_index,input_len=100)
